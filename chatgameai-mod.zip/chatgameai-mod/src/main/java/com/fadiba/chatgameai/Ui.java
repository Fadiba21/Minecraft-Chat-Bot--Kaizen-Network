package com.fadiba.chatgameai;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Pembantu gambar untuk layar pengaturan. */
final class Ui {
	private Ui() {
	}

	/** Garis pelangi yang bergerak (warna bergeser mengikuti waktu). */
	static void rainbowBar(GuiGraphicsExtractor g, int x, int y, int w, int h) {
		if (w <= 0) {
			return;
		}
		double ph = Fmt.phase(3000);
		for (int i = 0; i < w; i += 3) {
			float hue = (float) ((ph + (double) i / Math.max(60, w)) % 1.0);
			int rgb = Fmt.hsvRgb(hue, 0.85f, 1.0f);
			g.fill(x + i, y, Math.min(x + i + 3, x + w), y + h, 0xFF000000 | rgb);
		}
	}

	/** Potong teks supaya muat dalam lebar w piksel (diakhiri "…"). */
	static String clip(Font font, String s, int w) {
		if (s == null) {
			return "";
		}
		if (font.width(s) <= w) {
			return s;
		}
		String t = s;
		while (t.length() > 1 && font.width(t + "…") > w) {
			t = t.substring(0, t.length() - 1);
		}
		return t + "…";
	}
}
