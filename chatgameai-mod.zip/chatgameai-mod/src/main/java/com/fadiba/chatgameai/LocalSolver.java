package com.fadiba.chatgameai;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Solver lokal tanpa AI: soal "ketik", sandi geser huruf (Caesar), dan hitungan. Instan dan pasti benar. */
public final class LocalSolver {

	public record Result(String answer, String source) {
	}

	/** "The first to type 'sgo' wins!", "Ketik 'abc'", "Type the word 'xyz'" */
	private static final Pattern TYPE = Pattern.compile(
		"(?i)(?<!\\p{L})(?:first\\s+to\\s+(?:type|write)|type|ketik(?:kan)?)\\s*:?\\s*"
			+ "(?:(?:the\\s+)?(?:word|text|phrase|kata|teks)\\s*:?\\s*)?"
			+ "[\"'“‘`]([^\"'”’`]{1,60})[\"'”’`]");

	/** "(key: 3 down) Pecahkan: odpsx" */
	private static final Pattern KEY = Pattern.compile(
		"(?i)\\(?\\s*(?:key|kunci|shift|geser)\\s*[:=]\\s*(\\d{1,2})\\s*(down|up|turun|naik|bawah|atas|mundur|maju)\\s*\\)?");

	private static final Pattern MATH_CAT = Pattern.compile("(?i)mat|math|hitung|calc|angka|number|aritm|tambah|add|sum|jumlah");

	private LocalSolver() {
	}

	/** @return jawaban lokal, atau null jika soal ini harus dijawab AI. */
	public static Result solve(String category, String question) {
		String t = typeAnswer(question);
		if (t != null) {
			return new Result(t, "ketik");
		}
		String c = cipher(question);
		if (c != null) {
			return new Result(c, "sandi");
		}
		boolean allowWords = MATH_CAT.matcher(category == null ? "" : category).find() || MathSolver.hasHint(question);
		String m = MathSolver.solve(question, allowWords);
		if (m != null) {
			return new Result(m, "hitung");
		}
		return null;
	}

	/** Teks yang harus diketik persis, atau null. */
	public static String typeAnswer(String q) {
		if (q == null) {
			return null;
		}
		Matcher m = TYPE.matcher(q);
		if (m.find()) {
			String a = m.group(1).strip();
			return a.isEmpty() ? null : a;
		}
		return null;
	}

	/** Dekode sandi geser huruf. "down" = geser mundur N huruf, "up" = geser maju N huruf. */
	public static String cipher(String q) {
		if (q == null) {
			return null;
		}
		Matcher m = KEY.matcher(q);
		if (!m.find()) {
			return null;
		}
		int n = Integer.parseInt(m.group(1)) % 26;
		String dir = m.group(2).toLowerCase(Locale.ROOT);
		boolean down = dir.equals("down") || dir.equals("turun") || dir.equals("bawah") || dir.equals("mundur");
		String rest = (q.substring(0, m.start()) + " " + q.substring(m.end())).strip();
		int colon = rest.lastIndexOf(':');
		if (colon >= 0) {
			rest = rest.substring(colon + 1).strip();
		}
		rest = rest.replaceAll("\\(\\d+\\)\\s*$", "").replaceAll("[\\s.!?,;:]+$", "").strip();
		if (rest.isEmpty() || !rest.matches("[A-Za-z ]+")) {
			return null;
		}
		int shift = down ? -n : n;
		StringBuilder sb = new StringBuilder(rest.length());
		for (char ch : rest.toCharArray()) {
			if (ch >= 'a' && ch <= 'z') {
				sb.append((char) ('a' + ((ch - 'a' + shift) % 26 + 26) % 26));
			} else if (ch >= 'A' && ch <= 'Z') {
				sb.append((char) ('A' + ((ch - 'A' + shift) % 26 + 26) % 26));
			} else {
				sb.append(ch);
			}
		}
		return sb.toString();
	}
}
