package com.fadiba.chatgameai;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;

/** Format teks berwarna untuk pesan mod (tag pelangi, info biru muda, indikator ON/OFF). */
public final class Fmt {
	public static final String NAME = "EthenaLabs AI";

	public static final int INFO = 0x5CCBFF; // biru muda
	public static final int GREEN = 0x55FF55;
	public static final int RED = 0xFF5555;
	public static final int GOLD = 0xFFAA00;

	private Fmt() {
	}

	private static Style color(int rgb) {
		return Style.EMPTY.withColor(TextColor.fromRgb(rgb));
	}

	/** Teks dengan warna pelangi (RGB) per huruf. */
	public static MutableComponent rainbow(String s) {
		MutableComponent out = Component.empty();
		int n = Math.max(1, s.length());
		for (int i = 0; i < s.length(); i++) {
			float hue = 0.92f * i / n;
			out.append(Component.literal(String.valueOf(s.charAt(i))).withStyle(color(hsv(hue, 0.85f, 1.0f))));
		}
		return out;
	}

	/** [EthenaLabs AI] berwarna pelangi. */
	public static MutableComponent tag() {
		return rainbow("[" + NAME + "]");
	}

	/** Pesan informasi untuk client: tag pelangi + isi biru muda. */
	public static Component info(String msg) {
		MutableComponent c = Component.empty();
		c.append(tag());
		c.append(Component.literal(" " + msg).withStyle(color(INFO)));
		return c;
	}

	/** Indikator ON/OFF (action bar) saat keybind ditekan. */
	public static Component status(boolean on) {
		MutableComponent c = Component.empty();
		c.append(Component.literal("⚡ ").withStyle(color(GOLD)));
		c.append(rainbow(NAME));
		c.append(Component.literal("   "));
		c.append(Component.literal(on ? "✔ ON" : "✖ OFF").withStyle(color(on ? GREEN : RED).withBold(true)));
		return c;
	}

	/** Teks satu warna. */
	public static MutableComponent colored(String s, int rgb) {
		return Component.literal(s).withStyle(color(rgb));
	}

	/** Judul bagian (biru muda, tebal). */
	public static MutableComponent section(String s) {
		return Component.literal(s).withStyle(color(INFO).withBold(true));
	}

	/** "ON" hijau / "OFF" merah, tebal. */
	public static MutableComponent onOff(boolean on) {
		return Component.literal(on ? "ON" : "OFF").withStyle(color(on ? GREEN : RED).withBold(true));
	}

	/** Judul mod dengan ikon: petir emas + nama pelangi. */
	public static Component title() {
		MutableComponent c = Component.empty();
		c.append(Component.literal("\u26A1 ").withStyle(color(GOLD)));
		c.append(rainbow(NAME));
		return c;
	}

	/** Penanda status singkat: centang hijau ON / silang merah OFF. */
	public static Component statusShort(boolean on) {
		return Component.literal(on ? "\u2714 ON" : "\u2716 OFF").withStyle(color(on ? GREEN : RED).withBold(true));
	}

	private static int hsv(float h, float s, float v) {
		int i = (int) (h * 6f);
		float f = h * 6f - i;
		float p = v * (1f - s);
		float q = v * (1f - f * s);
		float t = v * (1f - (1f - f) * s);
		float r;
		float g;
		float b;
		switch (i % 6) {
			case 0 -> {
				r = v;
				g = t;
				b = p;
			}
			case 1 -> {
				r = q;
				g = v;
				b = p;
			}
			case 2 -> {
				r = p;
				g = v;
				b = t;
			}
			case 3 -> {
				r = p;
				g = q;
				b = v;
			}
			case 4 -> {
				r = t;
				g = p;
				b = v;
			}
			default -> {
				r = v;
				g = p;
				b = q;
			}
		}
		return (Math.round(r * 255) << 16) | (Math.round(g * 255) << 8) | Math.round(b * 255);
	}
}
