package com.fadiba.chatgameai;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;

/** Format teks berwarna: tag RGB, pesan info biru muda, status ON/OFF, notifikasi Terjawab/Telat. */
public final class Fmt {
	public static final String NAME = "Chatgpt-oss";

	public static final int INFO = 0x5CCBFF; // biru muda
	public static final int GREEN = 0x55FF55;
	public static final int RED = 0xFF5555;
	public static final int GOLD = 0xFFAA00;
	public static final int GRAY = 0xA0A0A0;
	public static final int ANSWERED = 0x8CFFA0; // hijau muda terang
	public static final int LATE = 0xFF8AC4; // merah muda

	private Fmt() {
	}

	private static Style color(int rgb) {
		return Style.EMPTY.withColor(TextColor.fromRgb(rgb));
	}

	/** Fase animasi 0..1 berdasarkan waktu (satu putaran = periodMs). */
	public static double phase(long periodMs) {
		return (System.currentTimeMillis() % periodMs) / (double) periodMs;
	}

	private static double wrap(double x) {
		return x - Math.floor(x);
	}

	// ------------------------------------------------------------------ RGB

	/** Teks pelangi (RGB) per huruf; phase menggeser warna sehingga bisa dianimasikan. */
	public static MutableComponent rainbow(String s, double phase) {
		MutableComponent out = Component.empty();
		int n = Math.max(1, s.length());
		for (int i = 0; i < s.length(); i++) {
			double h = wrap(phase + (double) i / n);
			out.append(Component.literal(String.valueOf(s.charAt(i))).withStyle(color(hsvRgb((float) h, 0.85f, 1.0f))));
		}
		return out;
	}

	public static MutableComponent rainbow(String s) {
		return rainbow(s, phase(4000));
	}

	/** [Chatgpt-oss] berwarna pelangi. */
	public static MutableComponent tag() {
		return rainbow("[" + NAME + "]");
	}

	/** Pesan informasi untuk client: tag pelangi + isi biru muda. */
	public static Component info(String msg) {
		MutableComponent c = Component.empty();
		c.append(tag());
		c.append(Component.literal(" " + msg).withStyle(color(INFO)));
		return c;
	}

	/** Status ON/OFF yang dikirim ke chat client saat keybind ditekan. */
	public static Component statusChat(boolean on) {
		MutableComponent c = Component.empty();
		c.append(tag());
		c.append(Component.literal(" ⚡ ").withStyle(color(GOLD)));
		c.append(Component.literal("Status: ").withStyle(color(INFO)));
		c.append(Component.literal(on ? "✔ ON" : "✖ OFF").withStyle(color(on ? GREEN : RED).withBold(true)));
		c.append(Component.literal(on ? "  - siap menjawab Chat Game" : "  - dimatikan").withStyle(color(GRAY)));
		return c;
	}

	// ------------------------------------------------------------------ notifikasi action bar

	/** Beberapa huruf acak (§k) berwarna RGB yang bergeser mengikuti phase. */
	public static MutableComponent scramble(int n, double phase) {
		MutableComponent out = Component.empty();
		for (int i = 0; i < n; i++) {
			double h = wrap(phase + (double) i / n);
			out.append(Component.literal("X").withStyle(color(hsvRgb((float) h, 0.9f, 1.0f)).withObfuscated(true)));
		}
		return out;
	}

	/** "XXXX Terjawab XXXX": kata berwarna di tengah, 4 huruf acak RGB di kiri dan kanan. */
	public static Component notice(String word, int rgb, double phase) {
		MutableComponent c = Component.empty();
		c.append(scramble(4, phase));
		c.append(Component.literal(" "));
		c.append(Component.literal(word).withStyle(color(rgb).withBold(true)));
		c.append(Component.literal(" "));
		c.append(scramble(4, -phase)); // arah geser warna berlawanan dengan sisi kiri
		return c;
	}

	// ------------------------------------------------------------------ untuk layar pengaturan

	public static MutableComponent colored(String s, int rgb) {
		return Component.literal(s).withStyle(color(rgb));
	}

	/** Judul bagian (biru muda, tebal). */
	public static MutableComponent section(String s) {
		return Component.literal(s).withStyle(color(INFO).withBold(true));
	}

	/** "ON" hijau / "OFF" merah, tebal. */
	public static MutableComponent onOff(boolean on) {
		return Component.literal(on ? "ON" : "OFF").withStyle(color(on ? GREEN : RED).withBold(true));
	}

	/** Judul layar: ikon emas + teks pelangi yang bergerak. */
	public static Component titled(String icon, String text, double phase) {
		MutableComponent c = Component.empty();
		c.append(Component.literal(icon + " ").withStyle(color(GOLD)));
		c.append(rainbow(text, phase));
		return c;
	}

	/** Penanda status singkat: centang hijau ON / silang merah OFF. */
	public static Component statusShort(boolean on) {
		return Component.literal(on ? "✔ ON" : "✖ OFF").withStyle(color(on ? GREEN : RED).withBold(true));
	}

	public static int hsvRgb(float h, float s, float v) {
		float hh = h - (float) Math.floor(h);
		int i = (int) (hh * 6f);
		float f = hh * 6f - i;
		float p = v * (1f - s);
		float q = v * (1f - f * s);
		float t = v * (1f - (1f - f) * s);
		float r;
		float g;
		float b;
		switch (i % 6) {
			case 0 -> {
				r = v;
				g = t;
				b = p;
			}
			case 1 -> {
				r = q;
				g = v;
				b = p;
			}
			case 2 -> {
				r = p;
				g = v;
				b = t;
			}
			case 3 -> {
				r = p;
				g = q;
				b = v;
			}
			case 4 -> {
				r = t;
				g = p;
				b = v;
			}
			default -> {
				r = v;
				g = p;
				b = q;
			}
		}
		return (Math.round(r * 255) << 16) | (Math.round(g * 255) << 8) | Math.round(b * 255);
	}
}
