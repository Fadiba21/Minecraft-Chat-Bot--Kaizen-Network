package com.fadiba.chatgameai;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Membaca pengumuman pemenang Chat Game, mis.
 * "CaSty_WaSty typed 'sgo' in 3.65 seconds!" atau "~JokoSukaLoncat solved 4 x 8 (32) in 3.2 seconds".
 * Kelas ini murni Java (tanpa Minecraft) supaya mudah dites.
 */
public final class AnnounceParser {
	public static final String DEFAULT_VERBS = "answered,typed,solved,unscrambled,guessed,decoded,deciphered";

	public record Result(String name, String verb) {
	}

	/** "in 3.65" / "in 3 seconds" */
	private static final Pattern TIME = Pattern.compile("(?i)\\bin\\s+\\d+(?:[.,]\\d+)?");

	private static String lastCsv;
	private static Pattern lastPattern;

	private AnnounceParser() {
	}

	/** @return nama pemenang + kata kerjanya, atau null jika baris ini bukan pengumuman pemenang. */
	public static Result parse(String text, String verbsCsv) {
		if (text == null) {
			return null;
		}
		String t = text.strip();
		// chat pemain biasa bukan pengumuman
		if (t.isEmpty() || t.startsWith("<") || t.indexOf('»') >= 0) {
			return null;
		}
		Matcher tm = TIME.matcher(t);
		if (!tm.find()) {
			return null;
		}
		int timeAt = tm.start();
		Pattern vp = verbPattern(verbsCsv);
		if (vp == null) {
			return null;
		}
		Matcher vm = vp.matcher(t);
		while (vm.find()) {
			if (vm.start() >= timeAt) {
				return null; // kata kerja harus muncul sebelum "in <waktu>"
			}
			String before = t.substring(0, vm.start()).strip();
			if (before.isEmpty()) {
				continue;
			}
			String[] tok = before.split("\\s+");
			String name = tok[tok.length - 1].replaceAll("^[^A-Za-z0-9_]+|[^A-Za-z0-9_]+$", "");
			if (name.isEmpty()) {
				continue;
			}
			return new Result(name, vm.group(1).toLowerCase(Locale.ROOT));
		}
		return null;
	}

	/** True jika nama pemenang adalah kita (IGN dari pengaturan, atau kata "you"/"kamu"). */
	public static boolean isMe(String winner, String ign) {
		if (winner == null) {
			return false;
		}
		if (ign != null && !ign.isBlank() && winner.equalsIgnoreCase(ign.strip())) {
			return true;
		}
		return winner.equalsIgnoreCase("you") || winner.equalsIgnoreCase("kamu") || winner.equalsIgnoreCase("anda");
	}

	private static synchronized Pattern verbPattern(String csv) {
		String c = (csv == null || csv.isBlank()) ? DEFAULT_VERBS : csv;
		if (!c.equals(lastCsv)) {
			StringBuilder sb = new StringBuilder();
			for (String v : c.split(",")) {
				String s = v.strip();
				if (!s.isEmpty()) {
					if (sb.length() > 0) {
						sb.append('|');
					}
					sb.append(Pattern.quote(s));
				}
			}
			lastCsv = c;
			lastPattern = sb.length() == 0 ? null
				: Pattern.compile("(?i)(?<![A-Za-z])(" + sb + ")(?![A-Za-z])");
		}
		return lastPattern;
	}
}
