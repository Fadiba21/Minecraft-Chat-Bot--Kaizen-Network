package com.fadiba.chatgameai;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;

/** Klien REST Gemini (generateContent). Koneksi dipakai ulang supaya cepat. */
public final class GeminiClient {
	private static final HttpClient HTTP = HttpClient.newBuilder()
		.connectTimeout(Duration.ofSeconds(5))
		.build();

	private GeminiClient() {
	}

	private static String base(ModConfig.Profile p) {
		String b = p.apiBase == null ? "" : p.apiBase.strip();
		while (b.endsWith("/")) {
			b = b.substring(0, b.length() - 1);
		}
		return b + "/models/" + p.model.strip();
	}

	public static CompletableFuture<String> ask(ModConfig.Profile p, String category, String question) {
		if (p.apiKey == null || p.apiKey.isBlank()) {
			return CompletableFuture.failedFuture(new IllegalStateException("API key kosong (isi di pengaturan mod)"));
		}
		try {
			JsonObject body = new JsonObject();
			body.add("systemInstruction", content(null, p.systemPrompt));
			JsonArray contents = new JsonArray();
			contents.add(content("user", "Jenis: " + category + "\nSoal: " + question));
			body.add("contents", contents);
			JsonObject gen = new JsonObject();
			gen.addProperty("temperature", p.temperature);
			gen.addProperty("maxOutputTokens", p.maxOutputTokens);
			body.add("generationConfig", gen);

			HttpRequest req = HttpRequest.newBuilder(URI.create(base(p) + ":generateContent"))
				.timeout(Duration.ofMillis(Math.max(1000, p.httpTimeoutMs)))
				.header("Content-Type", "application/json")
				.header("x-goog-api-key", p.apiKey.strip())
				.POST(HttpRequest.BodyPublishers.ofString(body.toString()))
				.build();

			return HTTP.sendAsync(req, HttpResponse.BodyHandlers.ofString()).thenApply(res -> {
				if (res.statusCode() / 100 != 2) {
					String b = res.body() == null ? "" : res.body().replaceAll("\\s+", " ");
					if (b.length() > 160) {
						b = b.substring(0, 160) + "...";
					}
					throw new CompletionException(new IOException("HTTP " + res.statusCode() + " " + b));
				}
				return parse(res.body());
			});
		} catch (Exception e) {
			return CompletableFuture.failedFuture(e);
		}
	}

	/** Buka koneksi lebih awal supaya soal pertama tidak kena biaya handshake. */
	public static void warmUp(ModConfig.Profile p) {
		if (p.apiKey == null || p.apiKey.isBlank()) {
			return;
		}
		try {
			HttpRequest req = HttpRequest.newBuilder(URI.create(base(p)))
				.timeout(Duration.ofSeconds(5))
				.header("x-goog-api-key", p.apiKey.strip())
				.GET()
				.build();
			HTTP.sendAsync(req, HttpResponse.BodyHandlers.discarding());
		} catch (Exception ignored) {
			// warm-up opsional
		}
	}

	private static JsonObject content(String role, String text) {
		JsonObject c = new JsonObject();
		if (role != null) {
			c.addProperty("role", role);
		}
		JsonArray parts = new JsonArray();
		JsonObject part = new JsonObject();
		part.addProperty("text", text);
		parts.add(part);
		c.add("parts", parts);
		return c;
	}

	private static String parse(String json) {
		JsonObject root = JsonParser.parseString(json).getAsJsonObject();
		JsonArray cands = root.has("candidates") ? root.getAsJsonArray("candidates") : null;
		if (cands == null || cands.isEmpty()) {
			throw new IllegalStateException("AI tidak memberi jawaban (mungkin diblokir)");
		}
		JsonObject cand = cands.get(0).getAsJsonObject();
		if (!cand.has("content") || !cand.get("content").isJsonObject()) {
			throw new IllegalStateException("AI tidak memberi jawaban");
		}
		JsonObject content = cand.getAsJsonObject("content");
		StringBuilder sb = new StringBuilder();
		if (content.has("parts")) {
			for (JsonElement e : content.getAsJsonArray("parts")) {
				JsonObject part = e.getAsJsonObject();
				if (part.has("thought") && part.get("thought").getAsBoolean()) {
					continue;
				}
				if (part.has("text")) {
					sb.append(part.get("text").getAsString());
				}
			}
		}
		String out = sb.toString().strip();
		if (out.isEmpty()) {
			throw new IllegalStateException("Jawaban AI kosong");
		}
		return out;
	}
}
