package com.fadiba.chatgameai;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Pengelola jawaban tersimpan: cari, lihat, edit, tambah, hapus satu atau semua. */
public final class AnswersScreen extends Screen {
	private static final int MAX_W = 440;
	private static final int ROW_H = 26;
	private static final int LIST_Y = 66;

	private final Screen parent;
	private int page;
	private String query;
	private final String armedKey;
	private final boolean armedAll;

	private List<Map.Entry<String, String>> rows = List.of();
	private int total;
	private int perPage;
	private int pages;
	private int cw;
	private int x0;

	/**
	 * @param parent   layar pengaturan yang membuka layar ini
	 * @param armedKey soal yang tombol hapusnya sedang menunggu konfirmasi (boleh null)
	 * @param armedAll true jika tombol "hapus semua" sedang menunggu konfirmasi
	 */
	public AnswersScreen(Screen parent, int page, String query, String armedKey, boolean armedAll) {
		super(Component.literal("Data Jawaban"));
		this.parent = parent;
		this.page = page;
		this.query = query == null ? "" : query;
		this.armedKey = armedKey;
		this.armedAll = armedAll;
	}

	@Override
	protected void init() {
		cw = Math.min(MAX_W, this.width - 12);
		x0 = (this.width - cw) / 2;

		List<Map.Entry<String, String>> all = AnswerStore.entries();
		total = all.size();
		String q = query.strip().toLowerCase(Locale.ROOT);
		if (q.isEmpty()) {
			rows = all;
		} else {
			List<Map.Entry<String, String>> f = new ArrayList<>();
			for (Map.Entry<String, String> e : all) {
				if (e.getKey().contains(q) || e.getValue().toLowerCase(Locale.ROOT).contains(q)) {
					f.add(e);
				}
			}
			rows = f;
		}
		perPage = Math.max(2, (this.height - LIST_Y - 58) / ROW_H);
		pages = Math.max(1, (rows.size() + perPage - 1) / perPage);
		page = Math.max(0, Math.min(pages - 1, page));

		// pencarian + tambah
		EditBox search = new EditBox(this.font, x0, 26, cw - 146, 18, Component.literal("Cari"));
		search.setMaxLength(100);
		search.setValue(query);
		search.setResponder(s -> query = s);
		addRenderableWidget(search);
		addRenderableWidget(Button.builder(Component.literal("Cari"), b -> open(0, null, false))
			.bounds(x0 + cw - 140, 25, 64, 20).build());
		addRenderableWidget(Button.builder(Component.literal("✚ Tambah"), b ->
				this.minecraft.gui.setScreen(new AnswerEditScreen(this, null, "", "")))
			.bounds(x0 + cw - 72, 25, 72, 20).build());

		// baris: tombol edit dan hapus
		int first = page * perPage;
		for (int i = 0; i < perPage && first + i < rows.size(); i++) {
			Map.Entry<String, String> e = rows.get(first + i);
			String key = e.getKey();
			String ans = e.getValue();
			int ry = LIST_Y + i * ROW_H;
			boolean armed = key.equals(armedKey);
			addRenderableWidget(Button.builder(Component.literal("✎"), b ->
					this.minecraft.gui.setScreen(new AnswerEditScreen(this, key, key, ans)))
				.bounds(x0 + cw - 68, ry, 24, 20).build());
			addRenderableWidget(Button.builder(Component.literal(armed ? "Yakin?" : "✖"), b -> {
				if (armed) {
					AnswerStore.remove(key);
					open(page, null, false);
				} else {
					open(page, key, false);
				}
			}).bounds(x0 + cw - 40, ry, 40, 20).build());
		}

		// footer: halaman + hapus semua + kembali
		Button prev = Button.builder(Component.literal("◀"), b -> open(page - 1, null, false))
			.bounds(x0, this.height - 50, 40, 20).build();
		prev.active = page > 0;
		addRenderableWidget(prev);
		Button next = Button.builder(Component.literal("▶"), b -> open(page + 1, null, false))
			.bounds(x0 + cw - 40, this.height - 50, 40, 20).build();
		next.active = page < pages - 1;
		addRenderableWidget(next);

		addRenderableWidget(Button.builder(Component.literal(armedAll ? "⚠ Yakin hapus SEMUA?" : "✖ Hapus semua"), b -> {
			if (armedAll) {
				AnswerStore.clear();
				open(0, null, false);
			} else {
				open(page, null, true);
			}
		}).bounds(x0, this.height - 24, Math.min(170, cw / 2 - 4), 20).build());
		addRenderableWidget(Button.builder(Component.literal("◀ Kembali"), b -> onClose())
			.bounds(x0 + cw - Math.min(120, cw / 2 - 4), this.height - 24, Math.min(120, cw / 2 - 4), 20).build());
	}

	private void open(int pg, String armed, boolean all) {
		this.minecraft.gui.setScreen(new AnswersScreen(parent, pg, query, armed, all));
	}

	@Override
	public void onClose() {
		this.minecraft.gui.setScreen(parent);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);

		graphics.fillGradient(0, 0, this.width, 15, 0xB0000000, 0x00000000);
		graphics.text(this.font, Fmt.titled("☰", "Data Jawaban", Fmt.phase(3000)), x0, 4, 0xFFFFFFFF, true);
		String count = query.isBlank() ? total + " soal" : rows.size() + " dari " + total + " soal";
		graphics.text(this.font, Fmt.colored(count, Fmt.GRAY), x0 + cw - this.font.width(count), 4, 0xFFFFFFFF, false);
		Ui.rainbowBar(graphics, x0, 48, cw, 1);

		int textW = cw - 74;
		int qW = (int) (textW * 0.62);
		int aW = textW - qW - 8;
		graphics.text(this.font, Fmt.colored("Soal", Fmt.GRAY), x0 + 4, LIST_Y - 12, 0xFFFFFFFF, false);
		graphics.text(this.font, Fmt.colored("Jawaban", Fmt.GRAY), x0 + 4 + qW + 8, LIST_Y - 12, 0xFFFFFFFF, false);

		int first = page * perPage;
		for (int i = 0; i < perPage && first + i < rows.size(); i++) {
			Map.Entry<String, String> e = rows.get(first + i);
			int ry = LIST_Y + i * ROW_H;
			// latar baris hanya di area teks (tidak menimpa tombol)
			graphics.fill(x0, ry, x0 + textW, ry + 20, (i % 2 == 0) ? 0x38FFFFFF : 0x22FFFFFF);
			graphics.fill(x0, ry, x0 + 2, ry + 20, 0xFF000000 | Fmt.INFO);
			graphics.text(this.font, Ui.clip(this.font, e.getKey(), qW), x0 + 6, ry + 6, 0xFFFFFFFF, false);
			graphics.text(this.font, Fmt.colored(Ui.clip(this.font, e.getValue(), aW), Fmt.ANSWERED),
				x0 + 6 + qW + 6, ry + 6, 0xFFFFFFFF, false);
		}
		if (rows.isEmpty()) {
			String msg = total == 0 ? "Belum ada jawaban tersimpan." : "Tidak ada yang cocok dengan pencarian.";
			graphics.text(this.font, Fmt.colored(msg, Fmt.GRAY), x0 + (cw - this.font.width(msg)) / 2, LIST_Y + 20, 0xFFFFFFFF, false);
		}

		String pg = "Hal " + (page + 1) + " / " + pages;
		graphics.text(this.font, pg, x0 + (cw - this.font.width(pg)) / 2, this.height - 44, 0xFFFFFFFF, false);
	}
}
