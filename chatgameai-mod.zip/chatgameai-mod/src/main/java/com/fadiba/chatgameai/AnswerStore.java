package com.fadiba.chatgameai;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Cache jawaban yang terbukti benar. Disimpan sebagai teks biasa di config/ethenalabs-answers.txt,
 * satu baris per soal: "soal ||| jawaban". Boleh diedit manual.
 */
public final class AnswerStore {
	private static final int MAX_ENTRIES = 5000;
	private static final String SEP = " ||| ";
	private static final String HEADER = "# EthenaLabs AI - data jawaban. Format: soal ||| jawaban (satu per baris)";
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("ethenalabs-answers.txt");
	private static final Path OLD_JSON = FabricLoader.getInstance().getConfigDir().resolve("chatgameai-answers.json");
	private static final Map<String, String> MAP = new LinkedHashMap<>();

	private AnswerStore() {
	}

	/** Normalisasi soal supaya soal yang sama persis (beda huruf besar/spasi) tetap cocok. */
	public static String norm(String s) {
		if (s == null) {
			return "";
		}
		return s.replaceAll("§.", "").toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").strip();
	}

	public static synchronized void load() {
		try {
			if (Files.exists(FILE)) {
				MAP.clear();
				for (String line : Files.readAllLines(FILE, StandardCharsets.UTF_8)) {
					String l = line.strip();
					if (l.isEmpty() || l.startsWith("#")) {
						continue;
					}
					int i = l.indexOf("|||");
					if (i <= 0) {
						continue;
					}
					String k = norm(l.substring(0, i));
					String v = l.substring(i + 3).strip();
					if (!k.isEmpty() && !v.isEmpty()) {
						MAP.put(k, v);
					}
				}
			} else if (Files.exists(OLD_JSON)) { // migrasi dari versi lama (JSON)
				Type t = new TypeToken<LinkedHashMap<String, String>>() {
				}.getType();
				Map<String, String> loaded = new Gson().fromJson(Files.readString(OLD_JSON, StandardCharsets.UTF_8), t);
				if (loaded != null) {
					MAP.clear();
					MAP.putAll(loaded);
				}
				save();
			} else {
				save(); // buat file kosong supaya mudah ditemukan
			}
		} catch (Exception e) {
			System.err.println("[EthenaLabs AI] Gagal membaca data jawaban: " + e);
		}
	}

	private static void save() {
		try {
			List<String> out = new ArrayList<>(MAP.size() + 1);
			out.add(HEADER);
			for (Map.Entry<String, String> e : MAP.entrySet()) {
				out.add(e.getKey() + SEP + e.getValue());
			}
			Files.write(FILE, out, StandardCharsets.UTF_8);
		} catch (Exception e) {
			System.err.println("[EthenaLabs AI] Gagal menyimpan data jawaban: " + e);
		}
	}

	public static synchronized String get(String key) {
		return MAP.get(key);
	}

	public static synchronized void put(String key, String answer) {
		if (key == null || key.isEmpty() || answer == null || answer.isBlank()) {
			return;
		}
		String k = key.replaceAll("[\\r\\n]+", " ").strip();
		String a = answer.replaceAll("[\\r\\n]+", " ").strip();
		MAP.remove(k); // pindah ke posisi paling baru
		MAP.put(k, a);
		while (MAP.size() > MAX_ENTRIES) {
			Iterator<String> it = MAP.keySet().iterator();
			it.next();
			it.remove();
		}
		save();
	}

	public static synchronized void clear() {
		MAP.clear();
		save();
	}

	public static synchronized int size() {
		return MAP.size();
	}
}
