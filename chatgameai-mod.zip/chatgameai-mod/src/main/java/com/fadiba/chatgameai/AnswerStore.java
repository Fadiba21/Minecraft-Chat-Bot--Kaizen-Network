package com.fadiba.chatgameai;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Cache jawaban yang sudah terbukti benar. Disimpan di config/chatgameai-answers.json */
public final class AnswerStore {
	private static final int MAX_ENTRIES = 5000;
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("chatgameai-answers.json");
	private static final Map<String, String> MAP = new LinkedHashMap<>();

	private AnswerStore() {
	}

	/** Normalisasi soal supaya soal yang sama persis (beda huruf besar/spasi) tetap cocok. */
	public static String norm(String s) {
		if (s == null) {
			return "";
		}
		return s.replaceAll("§.", "").toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").strip();
	}

	public static synchronized void load() {
		try {
			if (Files.exists(FILE)) {
				Type t = new TypeToken<LinkedHashMap<String, String>>() {
				}.getType();
				Map<String, String> loaded = GSON.fromJson(Files.readString(FILE, StandardCharsets.UTF_8), t);
				if (loaded != null) {
					MAP.clear();
					MAP.putAll(loaded);
				}
			}
		} catch (Exception e) {
			System.err.println("[ChatGameAI] Gagal membaca data jawaban: " + e);
		}
	}

	private static void save() {
		try {
			Files.writeString(FILE, GSON.toJson(MAP), StandardCharsets.UTF_8);
		} catch (Exception e) {
			System.err.println("[ChatGameAI] Gagal menyimpan data jawaban: " + e);
		}
	}

	public static synchronized String get(String key) {
		return MAP.get(key);
	}

	public static synchronized void put(String key, String answer) {
		if (key == null || key.isEmpty() || answer == null || answer.isBlank()) {
			return;
		}
		MAP.remove(key); // pindah ke posisi paling baru
		MAP.put(key, answer);
		while (MAP.size() > MAX_ENTRIES) {
			Iterator<String> it = MAP.keySet().iterator();
			it.next();
			it.remove();
		}
		save();
	}

	public static synchronized void clear() {
		MAP.clear();
		save();
	}

	public static synchronized int size() {
		return MAP.size();
	}
}
