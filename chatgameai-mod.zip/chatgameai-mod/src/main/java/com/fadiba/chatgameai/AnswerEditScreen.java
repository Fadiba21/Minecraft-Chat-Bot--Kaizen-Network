package com.fadiba.chatgameai;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Layar untuk melihat, mengubah, atau menambah satu jawaban. */
public final class AnswerEditScreen extends Screen {
	private final Screen back;
	private final String oldKey;
	private String q;
	private String a;
	private String error = "";
	private boolean armedDelete;
	private int cw;
	private int x0;

	/**
	 * @param back   layar daftar jawaban (dipakai untuk kembali)
	 * @param oldKey kunci soal yang diedit, atau null untuk entri baru
	 */
	public AnswerEditScreen(Screen back, String oldKey, String q, String a) {
		super(Component.literal(oldKey == null ? "Tambah Jawaban" : "Edit Jawaban"));
		this.back = back;
		this.oldKey = oldKey;
		this.q = q == null ? "" : q;
		this.a = a == null ? "" : a;
	}

	@Override
	protected void init() {
		cw = Math.min(400, this.width - 16);
		x0 = (this.width - cw) / 2;

		EditBox qBox = new EditBox(this.font, x0, 52, cw, 18, Component.literal("Soal"));
		qBox.setMaxLength(300);
		qBox.setValue(q);
		qBox.setResponder(s -> q = s);
		addRenderableWidget(qBox);

		EditBox aBox = new EditBox(this.font, x0, 92, cw, 18, Component.literal("Jawaban"));
		aBox.setMaxLength(100);
		aBox.setValue(a);
		aBox.setResponder(s -> a = s);
		addRenderableWidget(aBox);

		int by = 130;
		int n = oldKey == null ? 2 : 3;
		int bw = (cw - 6 * (n - 1)) / n;
		int bx = x0;
		addRenderableWidget(Button.builder(Component.literal("✔ Simpan"), b -> save())
			.bounds(bx, by, bw, 20).build());
		bx += bw + 6;
		if (oldKey != null) {
			addRenderableWidget(Button.builder(Component.literal("✖ Hapus"), b -> {
				if (armedDelete) {
					AnswerStore.remove(oldKey);
					this.minecraft.gui.setScreen(back);
				} else {
					armedDelete = true;
					b.setMessage(Component.literal("⚠ Yakin hapus?"));
				}
			}).bounds(bx, by, bw, 20).build());
			bx += bw + 6;
		}
		addRenderableWidget(Button.builder(Component.literal("◀ Batal"), b -> onClose())
			.bounds(bx, by, bw, 20).build());
	}

	private void save() {
		String nk = AnswerStore.norm(q);
		String na = a == null ? "" : a.strip();
		if (nk.isEmpty() || na.isEmpty()) {
			error = "Soal dan jawaban tidak boleh kosong.";
			return;
		}
		AnswerStore.replace(oldKey, nk, na);
		this.minecraft.gui.setScreen(back);
	}

	@Override
	public void onClose() {
		this.minecraft.gui.setScreen(back);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);

		graphics.fillGradient(0, 0, this.width, 15, 0xB0000000, 0x00000000);
		graphics.text(this.font, Fmt.titled(oldKey == null ? "✚" : "✎", this.title.getString(), Fmt.phase(3000)),
			x0, 4, 0xFFFFFFFF, true);
		Ui.rainbowBar(graphics, x0, 22, cw, 1);

		graphics.text(this.font, Fmt.colored("Soal (huruf besar/kecil diabaikan)", Fmt.GRAY), x0, 40, 0xFFFFFFFF, false);
		graphics.text(this.font, Fmt.colored("Jawaban (dikirim ke chat persis seperti ini)", Fmt.GRAY), x0, 80, 0xFFFFFFFF, false);
		if (!error.isEmpty()) {
			graphics.text(this.font, Fmt.colored(error, Fmt.RED), x0, 118, 0xFFFFFFFF, false);
		}
		graphics.text(this.font, Fmt.colored("Tersimpan di config/chatgptoss-answers.txt", Fmt.GRAY), x0, 160, 0xFFFFFFFF, false);
	}
}
