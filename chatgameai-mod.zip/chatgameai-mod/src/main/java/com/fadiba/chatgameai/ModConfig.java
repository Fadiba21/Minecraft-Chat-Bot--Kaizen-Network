package com.fadiba.chatgameai;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Pengaturan mod + sistem profil. Disimpan di config/chatgameai.json */
public final class ModConfig {

	public static final String DEFAULT_PROMPT =
		"Kamu pemain yang menjawab kuis 'Chat Game' di server Minecraft. "
			+ "Aturan: jawab HANYA jawabannya, 1 sampai 3 kata, tanpa penjelasan, tanpa kalimat, "
			+ "tanpa tanda kutip, tanpa titik di akhir. Jawab dengan bahasa yang sama dengan soal. "
			+ "Soal hitungan: jawab angkanya saja. Soal acak huruf: jawab kata yang benar. "
			+ "Soal melengkapi kata: jawab kata yang diminta saja. Jika ragu, tebak jawaban paling mungkin.";

	public static final String DEFAULT_REVEAL_REGEX =
		"(?i)(?:jawaban(?:\\s+yang)?\\s+benar|jawabannya|correct\\s+answer|the\\s+answer\\s+was)\\s*(?:adalah|is|:|=)?\\s*:?\\s*(.+)$";

	/** Satu profil = satu set pengaturan lengkap. */
	public static final class Profile {
		// --- umum ---
		public boolean enabled = true;
		public boolean showInfoInChat = true;
		public boolean debug = false;

		// --- deteksi ---
		public String triggerKeyword = "Chat Game";
		public int maxLinesAfterTrigger = 4;
		public int captureTimeoutMs = 4000;
		public boolean ignorePlayerChat = true;
		public boolean detectMathWithoutTag = true;
		public String ignoredCategories = "";

		// --- jawaban / cache ---
		public boolean localMathSolver = true;
		public boolean useCache = true;
		public boolean saveUnverified = false;
		public String winKeywords = "benar,correct,menang,winner,berhasil,selamat";
		public String revealRegex = DEFAULT_REVEAL_REGEX;
		public int confirmWindowMs = 15000;
		public int minDelayMs = 0;
		public int maxDelayMs = 0;
		public int cooldownMs = 1500;

		// --- format jawaban ---
		public int maxWords = 3;
		public String answerCase = "ASIS"; // ASIS | LOWER | UPPER
		public boolean stripTrailingPunct = true;

		// --- AI ---
		public String apiKey = "";
		public String model = "gemini-3.5-flash-lite";
		public String apiBase = "https://generativelanguage.googleapis.com/v1beta";
		public double temperature = 0.2;
		public int maxOutputTokens = 128;
		public int httpTimeoutMs = 6000;
		public String systemPrompt = DEFAULT_PROMPT;

		public Profile copy() {
			return GSON.fromJson(GSON.toJson(this), Profile.class);
		}
	}

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("chatgameai.json");
	private static ModConfig instance = new ModConfig();

	public String activeProfile = "Default";
	public Map<String, Profile> profiles = new LinkedHashMap<>();

	private ModConfig() {
	}

	public static synchronized void load() {
		try {
			if (Files.exists(FILE)) {
				ModConfig loaded = GSON.fromJson(Files.readString(FILE, StandardCharsets.UTF_8), ModConfig.class);
				if (loaded != null) {
					instance = loaded;
				}
			}
		} catch (Exception e) {
			System.err.println("[ChatGameAI] Gagal membaca config: " + e);
		}
		ensure();
		save();
	}

	public static synchronized void save() {
		try {
			Files.writeString(FILE, GSON.toJson(instance), StandardCharsets.UTF_8);
		} catch (Exception e) {
			System.err.println("[ChatGameAI] Gagal menyimpan config: " + e);
		}
	}

	private static void ensure() {
		if (instance.profiles == null) {
			instance.profiles = new LinkedHashMap<>();
		}
		if (instance.profiles.isEmpty()) {
			instance.profiles.put("Default", new Profile());
		}
		if (instance.activeProfile == null || !instance.profiles.containsKey(instance.activeProfile)) {
			instance.activeProfile = instance.profiles.keySet().iterator().next();
		}
	}

	public static synchronized Profile active() {
		ensure();
		return instance.profiles.get(instance.activeProfile);
	}

	public static synchronized String activeName() {
		ensure();
		return instance.activeProfile;
	}

	public static synchronized List<String> names() {
		ensure();
		return new ArrayList<>(instance.profiles.keySet());
	}

	public static synchronized void setActive(String name) {
		if (instance.profiles.containsKey(name)) {
			instance.activeProfile = name;
			save();
		}
	}

	/** Buat profil baru dari salinan profil aktif lalu aktifkan. */
	public static synchronized boolean addProfile(String name) {
		name = name == null ? "" : name.strip();
		if (name.isEmpty() || instance.profiles.containsKey(name)) {
			return false;
		}
		instance.profiles.put(name, active().copy());
		instance.activeProfile = name;
		save();
		return true;
	}

	public static synchronized boolean deleteActive() {
		if (instance.profiles.size() <= 1) {
			return false;
		}
		instance.profiles.remove(instance.activeProfile);
		instance.activeProfile = instance.profiles.keySet().iterator().next();
		save();
		return true;
	}

	/** Reset profil aktif ke default (API key dipertahankan). */
	public static synchronized void resetActive() {
		String key = active().apiKey;
		Profile fresh = new Profile();
		fresh.apiKey = key;
		instance.profiles.put(instance.activeProfile, fresh);
		save();
	}
}
