package com.fadiba.chatgameai;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;

/**
 * Notifikasi action bar ("Terjawab" / "Telat") dengan huruf acak RGB yang bergerak.
 * Pesan dikirim ulang tiap tick supaya warnanya bergeser, lalu dihapus tepat saat durasi habis.
 */
public final class Notifier {
	private static boolean active;
	private static String word = "";
	private static int rgb;
	private static long start;
	private static long end;

	private Notifier() {
	}

	public static synchronized void show(String text, int color, int durationMs) {
		word = text;
		rgb = color;
		start = System.currentTimeMillis();
		end = start + Math.max(ModConfig.NOTIFY_MIN, Math.min(ModConfig.NOTIFY_MAX, durationMs));
		active = true;
	}

	/** Dipanggil tiap client tick. */
	public static synchronized void tick(Minecraft mc) {
		if (!active) {
			return;
		}
		LocalPlayer player = mc.player;
		if (player == null) {
			active = false;
			return;
		}
		long now = System.currentTimeMillis();
		if (now >= end) {
			player.sendOverlayMessage(Component.empty()); // hapus agar tidak tertinggal 3 detik lagi
			active = false;
			return;
		}
		double phase = ((now - start) % 1200L) / 1200.0;
		player.sendOverlayMessage(Fmt.notice(word, rgb, phase));
	}
}
