package com.fadiba.chatgameai;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Penyelesai soal matematika lokal (tanpa AI = instan). */
public final class MathSolver {
	private static final Pattern ALLOWED = Pattern.compile("^[0-9+\\-*/^%().]+$");
	private static final Pattern CANDIDATE = Pattern.compile("[0-9(][0-9\\s+\\-*/x×÷^%().,]*[0-9)]");
	private static final Pattern HINT = Pattern.compile(
		"(?i)(?<!\\p{L})(berapa|hasil|hitung|hitunglah|jumlah|jumlahkan|tambah|ditambah|kurang|dikurang|kali|dikali"
			+ "|bagi|dibagi|plus|minus|solve|calculate|compute|what\\s+is|sum|math|matematika)(?!\\p{L})");

	private MathSolver() {
	}

	/** True jika ada kata petunjuk hitungan (berapa, hasil, plus, solve, ...). */
	public static boolean hasHint(String s) {
		return s != null && HINT.matcher(s).find();
	}

	/** True jika baris ini terlihat seperti soal hitungan: ekspresi murni, atau kalimat berisi ekspresi + kata petunjuk. */
	public static boolean looksLikeMath(String line) {
		return prepare(line) != null || (hasHint(line) && extract(line) != null);
	}

	public static String solve(String line) {
		return solve(line, false);
	}

	/**
	 * Hasil sebagai teks, atau null jika tidak bisa dihitung.
	 *
	 * @param allowWords true = boleh mengambil ekspresi dari dalam kalimat ("Berapa 12 ditambah 5?")
	 */
	public static String solve(String line, boolean allowWords) {
		String e = prepare(line);
		if (e == null && allowWords) {
			e = extract(line);
		}
		if (e == null) {
			return null;
		}
		try {
			double v = new Parser(e).parse();
			if (Double.isNaN(v) || Double.isInfinite(v)) {
				return null;
			}
			BigDecimal bd = BigDecimal.valueOf(v).setScale(4, RoundingMode.HALF_UP).stripTrailingZeros();
			if (bd.scale() < 0) {
				bd = bd.setScale(0);
			}
			return bd.toPlainString();
		} catch (RuntimeException ex) {
			return null;
		}
	}

	private static String normalize(String s) {
		String t = Normalizer.normalize(s, Normalizer.Form.NFKC);
		t = t.replaceAll("[\\u200B-\\u200F\\u2060\\uFEFF]", "");
		return t.replace('➕', '+').replace('➖', '-').replace('✖', '*')
			.replace('✕', '*').replace('➗', '/').replace('∗', '*');
	}

	/** Ambil ekspresi dari dalam kalimat, termasuk operator berupa kata (plus, ditambah, kali, ...). */
	private static String extract(String s) {
		if (s == null) {
			return null;
		}
		String t = normalize(s).toLowerCase(Locale.ROOT);
		t = t.replaceAll("(?<!\\p{L})(ditambahkan|ditambah|tambahkan|tambah|plus)(?!\\p{L})", "+");
		t = t.replaceAll("(?<!\\p{L})(dikurangi|dikurang|kurangi|kurang|minus)(?!\\p{L})", "-");
		t = t.replaceAll("(?<!\\p{L})(dikalikan|dikali|kalikan|kali|times)(?!\\p{L})", "*");
		t = t.replaceAll("(?<!\\p{L})(dibagi|bagi|divided\\s+by)(?!\\p{L})", "/");
		Matcher m = CANDIDATE.matcher(t);
		String best = null;
		while (m.find()) {
			String e = prepare(m.group());
			if (e != null && (best == null || e.length() > best.length())) {
				best = e;
			}
		}
		return best;
	}

	private static String prepare(String s) {
		if (s == null) {
			return null;
		}
		String t = normalize(s).toLowerCase(Locale.ROOT).strip();
		t = t.replaceAll("[=?\\s]+$", "");
		t = t.replace('×', '*').replace('÷', '/').replace('−', '-');
		t = t.replaceAll("(?<=\\d),(?=\\d{3}(?!\\d))", ""); // 1,234 -> 1234
		t = t.replace(',', '.');
		t = t.replaceAll("(?<=[0-9)])\\s*x\\s*(?=[0-9(])", "*");
		t = t.replaceAll("\\s+", "");
		if (t.isEmpty() || !ALLOWED.matcher(t).matches()) {
			return null;
		}
		if (!t.matches(".*[0-9].*")) {
			return null;
		}
		// harus ada operator selain tanda minus di depan
		if (!t.substring(1).matches(".*[+\\-*/^%].*")) {
			return null;
		}
		return t;
	}

	private static final class Parser {
		private final String s;
		private int pos;

		Parser(String s) {
			this.s = s;
		}

		double parse() {
			double v = expr();
			if (pos != s.length()) {
				throw new IllegalStateException("sisa input");
			}
			return v;
		}

		private double expr() {
			double v = term();
			while (pos < s.length()) {
				char c = s.charAt(pos);
				if (c == '+') {
					pos++;
					v += term();
				} else if (c == '-') {
					pos++;
					v -= term();
				} else {
					break;
				}
			}
			return v;
		}

		private double term() {
			double v = unary();
			while (pos < s.length()) {
				char c = s.charAt(pos);
				if (c == '*') {
					pos++;
					v *= unary();
				} else if (c == '/') {
					pos++;
					v /= unary();
				} else if (c == '%') {
					pos++;
					v %= unary();
				} else {
					break;
				}
			}
			return v;
		}

		private double unary() {
			if (pos < s.length() && s.charAt(pos) == '-') {
				pos++;
				return -unary();
			}
			if (pos < s.length() && s.charAt(pos) == '+') {
				pos++;
				return unary();
			}
			return power();
		}

		private double power() {
			double base = primary();
			if (pos < s.length() && s.charAt(pos) == '^') {
				pos++;
				return Math.pow(base, unary());
			}
			return base;
		}

		private double primary() {
			if (pos >= s.length()) {
				throw new IllegalStateException("input habis");
			}
			char c = s.charAt(pos);
			if (c == '(') {
				pos++;
				double v = expr();
				if (pos >= s.length() || s.charAt(pos) != ')') {
					throw new IllegalStateException("kurung");
				}
				pos++;
				return v;
			}
			int start = pos;
			while (pos < s.length() && (Character.isDigit(s.charAt(pos)) || s.charAt(pos) == '.')) {
				pos++;
			}
			if (start == pos) {
				throw new IllegalStateException("angka");
			}
			return Double.parseDouble(s.substring(start, pos));
		}
	}
}
