package com.fadiba.chatgameai;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;
import java.util.regex.Pattern;

/** Penyelesai soal matematika lokal (tanpa AI = instan). Hanya ekspresi murni angka dan operator. */
public final class MathSolver {
	private static final Pattern ALLOWED = Pattern.compile("^[0-9+\\-*/^%().]+$");

	private MathSolver() {
	}

	/** True jika baris ini terlihat seperti soal hitungan murni, mis. "12 x 5 + 3 = ?" */
	public static boolean looksLikeMath(String line) {
		return prepare(line) != null;
	}

	/** Hasil sebagai teks, atau null jika bukan ekspresi yang bisa dihitung. */
	public static String solve(String line) {
		String e = prepare(line);
		if (e == null) {
			return null;
		}
		try {
			double v = new Parser(e).parse();
			if (Double.isNaN(v) || Double.isInfinite(v)) {
				return null;
			}
			BigDecimal bd = BigDecimal.valueOf(v).setScale(4, RoundingMode.HALF_UP).stripTrailingZeros();
			if (bd.scale() < 0) {
				bd = bd.setScale(0);
			}
			return bd.toPlainString();
		} catch (RuntimeException ex) {
			return null;
		}
	}

	private static String prepare(String s) {
		if (s == null) {
			return null;
		}
		String t = s.toLowerCase(Locale.ROOT).strip();
		t = t.replaceAll("[=?\\s]+$", "");
		t = t.replace('×', '*').replace('÷', '/').replace('−', '-').replace(',', '.');
		t = t.replaceAll("(?<=[0-9)])\\s*x\\s*(?=[0-9(])", "*");
		t = t.replaceAll("\\s+", "");
		if (t.isEmpty() || !ALLOWED.matcher(t).matches()) {
			return null;
		}
		if (!t.matches(".*[0-9].*")) {
			return null;
		}
		// harus ada operator selain tanda minus di depan
		if (!t.substring(1).matches(".*[+\\-*/^%].*")) {
			return null;
		}
		return t;
	}

	private static final class Parser {
		private final String s;
		private int pos;

		Parser(String s) {
			this.s = s;
		}

		double parse() {
			double v = expr();
			if (pos != s.length()) {
				throw new IllegalStateException("sisa input");
			}
			return v;
		}

		private double expr() {
			double v = term();
			while (pos < s.length()) {
				char c = s.charAt(pos);
				if (c == '+') {
					pos++;
					v += term();
				} else if (c == '-') {
					pos++;
					v -= term();
				} else {
					break;
				}
			}
			return v;
		}

		private double term() {
			double v = unary();
			while (pos < s.length()) {
				char c = s.charAt(pos);
				if (c == '*') {
					pos++;
					v *= unary();
				} else if (c == '/') {
					pos++;
					v /= unary();
				} else if (c == '%') {
					pos++;
					v %= unary();
				} else {
					break;
				}
			}
			return v;
		}

		private double unary() {
			if (pos < s.length() && s.charAt(pos) == '-') {
				pos++;
				return -unary();
			}
			if (pos < s.length() && s.charAt(pos) == '+') {
				pos++;
				return unary();
			}
			return power();
		}

		private double power() {
			double base = primary();
			if (pos < s.length() && s.charAt(pos) == '^') {
				pos++;
				return Math.pow(base, unary());
			}
			return base;
		}

		private double primary() {
			if (pos >= s.length()) {
				throw new IllegalStateException("input habis");
			}
			char c = s.charAt(pos);
			if (c == '(') {
				pos++;
				double v = expr();
				if (pos >= s.length() || s.charAt(pos) != ')') {
					throw new IllegalStateException("kurung");
				}
				pos++;
				return v;
			}
			int start = pos;
			while (pos < s.length() && (Character.isDigit(s.charAt(pos)) || s.charAt(pos) == '.')) {
				pos++;
			}
			if (start == pos) {
				throw new IllegalStateException("angka");
			}
			return Double.parseDouble(s.substring(start, pos));
		}
	}
}
