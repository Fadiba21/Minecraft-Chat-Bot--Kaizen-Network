package com.fadiba.chatgameai;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;

import java.util.Arrays;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/** Mendeteksi "Chat Game" di chat server, menjawab otomatis lewat akun client, lalu menilai siapa pemenangnya. */
public final class ChatGameEngine {
	private static final Pattern TAG = Pattern.compile("^[^\\[\\]]{0,12}\\[([^\\]]{1,40})\\]\\s*(\\S.*)$");
	private static final Pattern TAG_START = Pattern.compile("^\\[([^\\]]{1,40})\\]\\s*(\\S.*)$");
	private static final Pattern MATH_CAT = Pattern.compile("(?i)mat|math|hitung|calc|angka|number|aritm|tambah|add|sum|jumlah");
	private static final Pattern SCRAMBLE = Pattern.compile("(?i)pecahkan|acak|scramble|unscramble|anagram|susun|sandi|cipher|key\\s*:");
	/** Chat pemain gaya "Rank | Nama » pesan" */
	private static final Pattern PLAYER_ARROW = Pattern.compile("^.{1,60}\\s»\\s");
	/** Pengumuman pemenang yang memuat jawaban: "Nama solved 4 x 8 (32) in 3.2 seconds" */
	private static final Pattern BUILTIN_REVEAL = Pattern.compile("(?i)\\bsolved\\b.*?\\(([^()]{1,60})\\)\\s*in\\b");
	private static final String BUILTIN_WIN = "solved,typed,unscrambled,answered,correct,benar,menang,winner,won,berhasil,selamat";

	private record Pending(String key, String answer, String source) {
	}

	private static boolean waiting;
	private static long deadline;
	private static int lines;

	private static String lastText = "";
	private static long lastTextAt;

	private static String lastKey = "";
	private static long lastKeyAt;
	private static String resolvedKey = "";
	private static long lastAnswerAt;
	private static int round;
	private static boolean roundNotified;
	private static Pending pending;

	private static String revealSrc;
	private static Pattern revealPat;

	private ChatGameEngine() {
	}

	// ------------------------------------------------------------------ pesan masuk

	public static void onMessage(Component component) {
		if (!ModConfig.isEnabled()) {
			return;
		}
		ModConfig.Profile p = ModConfig.active();
		String full = component.getString().replaceAll("§.", "").strip();
		if (full.isEmpty() || full.startsWith("[" + Fmt.NAME + "]")
			|| full.startsWith("[EthenaLabs AI]") || full.startsWith("[ChatGameAI]")) {
			return;
		}
		long now = System.currentTimeMillis();
		if (full.equals(lastText) && now - lastTextAt < 100) {
			return; // pesan ganda dari dua jalur event
		}
		lastText = full;
		lastTextAt = now;

		// satu pesan bisa berisi beberapa baris: proses satu per satu
		for (String raw : full.split("\\R")) {
			String line = raw.strip();
			if (!line.isEmpty()) {
				handleLine(p, line, now);
			}
		}
	}

	private static void handleLine(ModConfig.Profile p, String text, long now) {
		checkConfirmation(p, text, now);
		if (checkAnnouncement(p, text, now)) {
			return;
		}

		String kw = p.triggerKeyword == null ? "" : p.triggerKeyword.strip();
		int kwIdx = kw.isEmpty() ? -1 : indexOfIgnoreCase(text, kw);

		if (kwIdx >= 0 && !(p.ignorePlayerChat && text.startsWith("<"))) {
			waiting = true;
			deadline = now + p.captureTimeoutMs;
			lines = 0;
			String rem = text.substring(kwIdx + kw.length()).replaceFirst("^[\\]\\s:>»|\\-*=~]+", "");
			if (handleCandidate(p, rem, now)) {
				waiting = false;
			}
			return;
		}

		if (waiting) {
			if (now > deadline) {
				waiting = false;
				return;
			}
			if (p.ignorePlayerChat && (text.startsWith("<") || PLAYER_ARROW.matcher(text).find())) {
				return; // chat pemain lain, jangan dihitung sebagai baris soal
			}
			if (handleCandidate(p, text, now)) {
				waiting = false;
			} else {
				debug(p, "Baris diabaikan: " + text);
				if (++lines >= p.maxLinesAfterTrigger) {
					waiting = false;
				}
			}
		}
	}

	/** @return true jika baris ini dikenali sebagai soal. */
	private static boolean handleCandidate(ModConfig.Profile p, String line, long now) {
		if (line == null || line.isBlank()) {
			return false;
		}
		Matcher m = TAG.matcher(line);
		if (m.find()) {
			String cat = m.group(1).strip();
			String q = m.group(2).strip();
			for (int i = 0; i < 2; i++) {
				Matcher m2 = TAG_START.matcher(q);
				if (m2.matches()) {
					cat = m2.group(1).strip();
					q = m2.group(2).strip();
				} else {
					break;
				}
			}
			if (cat.equalsIgnoreCase(p.triggerKeyword)) {
				cat = "Umum";
			}
			process(p, cat, q, now);
			return true;
		}
		String plain = line.strip();
		// soal tanpa tag: "The first to type 'sgo' wins!"
		if (LocalSolver.typeAnswer(plain) != null) {
			process(p, "Ketik", plain, now);
			return true;
		}
		// soal hitungan tanpa tag, mis. '4 x 8 = ?'
		if (p.detectMathWithoutTag && MathSolver.looksLikeMath(plain)) {
			process(p, "Matematika", plain, now);
			return true;
		}
		return false;
	}

	// ------------------------------------------------------------------ menjawab

	private static void process(ModConfig.Profile p, String category, String question, long now) {
		String key = AnswerStore.norm(question);
		if (key.isEmpty() || isIgnored(p, category)) {
			return;
		}
		if (key.equals(lastKey) && now - lastKeyAt < 3000) {
			return; // soal yang sama baru saja diproses
		}
		if (now - lastAnswerAt < p.cooldownMs) {
			debug(p, "Cooldown, soal dilewati");
			return;
		}
		lastKey = key;
		lastKeyAt = now;
		roundNotified = false;
		pending = null;
		int myRound = ++round;
		debug(p, "Soal [" + category + "] " + question);

		if (p.localMathSolver) {
			LocalSolver.Result r = LocalSolver.solve(category, question);
			if (r != null) {
				ModConfig.DelayType t = classify(category, question, r.source());
				if (skipType(p, t)) {
					return;
				}
				reply(p, r.answer(), r.source(), t, key, myRound, now);
				return;
			}
		}
		if (p.useCache) {
			String cached = AnswerStore.get(key);
			if (cached != null) {
				ModConfig.DelayType t = classify(category, question, "cache");
				if (skipType(p, t)) {
					return;
				}
				reply(p, cached, "cache", t, key, myRound, now);
				return;
			}
		}

		ModConfig.DelayType type = classify(category, question, "ai");
		if (skipType(p, type)) {
			return;
		}
		GeminiClient.ask(p, category, question).whenComplete((ans, err) -> runOnMain(() -> {
			if (myRound != round) {
				return;
			}
			if (err != null) {
				Throwable t = err instanceof CompletionException && err.getCause() != null ? err.getCause() : err;
				String msg = t.getMessage() != null ? t.getMessage() : t.getClass().getSimpleName();
				info(p, "AI gagal: " + msg);
				return;
			}
			reply(p, ans, "ai", type, key, myRound, now);
		}));
	}

	/** True (dan ronde dibatalkan) jika jenis soal ini dimatikan di pengaturan. */
	private static boolean skipType(ModConfig.Profile p, ModConfig.DelayType t) {
		if (p.typeEnabled(t)) {
			return false;
		}
		lastKey = ""; // ronde ini tidak diikuti, jangan tampilkan Terjawab/Telat
		debug(p, "Jenis '" + t.label + "' dimatikan, soal dilewati");
		return true;
	}

	/** Tentukan tipe soal untuk memilih pengaturan delay. */
	private static ModConfig.DelayType classify(String category, String question, String source) {
		switch (source) {
			case "ketik":
				return ModConfig.DelayType.TYPE;
			case "sandi":
				return ModConfig.DelayType.SCRAMBLE;
			case "hitung":
				return ModConfig.DelayType.MATH;
			default:
				break;
		}
		String cat = category == null ? "" : category;
		if (LocalSolver.typeAnswer(question) != null) {
			return ModConfig.DelayType.TYPE;
		}
		if (MATH_CAT.matcher(cat).find()) {
			return ModConfig.DelayType.MATH;
		}
		if (SCRAMBLE.matcher(cat).find() || SCRAMBLE.matcher(question).find()) {
			return ModConfig.DelayType.SCRAMBLE;
		}
		return ModConfig.DelayType.GENERAL;
	}

	private static void reply(ModConfig.Profile p, String raw, String source, ModConfig.DelayType type,
							  String key, int myRound, long startedAt) {
		// jawaban soal "ketik" harus persis, jadi tidak dibersihkan/diubah hurufnya
		String answer = "ketik".equals(source) ? (raw == null ? "" : raw.strip()) : cleanAnswer(p, raw);
		if (answer.isEmpty()) {
			return;
		}
		long computeMs = System.currentTimeMillis() - startedAt;
		int delay = p.delay(type).resolve();

		Runnable send = () -> {
			if (myRound != round || !ModConfig.isEnabled()) {
				return;
			}
			LocalPlayer player = Minecraft.getInstance().player;
			if (player == null) {
				return;
			}
			player.connection.sendChat(answer);
			long t = System.currentTimeMillis();
			lastAnswerAt = t;
			pending = new Pending(key, answer, source);
			ModConfig.stats().count(source, computeMs);
			if ("ai".equals(source) && p.saveUnverified) {
				AnswerStore.put(key, answer);
			}
			info(p, "Jawab (" + source + ", " + type.label + ", siap " + computeMs + " ms, delay "
				+ String.format(Locale.ROOT, "%.1f", delay / 1000.0) + " s): " + answer);
		};

		if (delay <= 0) {
			runOnMain(send);
		} else {
			CompletableFuture.runAsync(() -> runOnMain(send), CompletableFuture.delayedExecutor(delay, TimeUnit.MILLISECONDS));
		}
	}

	// ------------------------------------------------------------------ pemenang: Terjawab / Telat

	/**
	 * Mengenali pengumuman pemenang ("Nama typed 'x' in 3.6 seconds").
	 * Jika pemenangnya IGN kita -> "Terjawab", jika orang lain -> "Telat".
	 *
	 * @return true jika baris ini adalah pengumuman pemenang untuk ronde yang sedang diikuti
	 */
	private static boolean checkAnnouncement(ModConfig.Profile p, String text, long now) {
		if (lastKey.isEmpty() || now - lastKeyAt > p.confirmWindowMs) {
			return false;
		}
		AnnounceParser.Result r = AnnounceParser.parse(text, p.winVerbs);
		if (r == null) {
			return false;
		}
		if (roundNotified) {
			return true; // pengumuman ganda untuk ronde yang sama
		}
		roundNotified = true;
		round++; // ronde selesai: batalkan jawaban yang masih menunggu delay / AI
		waiting = false;

		boolean mine = AnnounceParser.isMe(r.name(), myName(p));
		ModConfig.Stats st = ModConfig.stats();
		if (mine) {
			st.won++;
			Pending pd = pending;
			if (pd != null && "ai".equals(pd.source()) && !pd.key().equals(resolvedKey)) {
				AnswerStore.put(pd.key(), pd.answer()); // jawaban AI terbukti benar
				resolvedKey = pd.key();
				pending = null;
				info(p, "Jawaban benar tersimpan: " + pd.answer());
			}
			notice(p, "Terjawab", Fmt.ANSWERED);
		} else {
			st.late++;
			notice(p, "Telat", Fmt.LATE);
		}
		ModConfig.save();
		debug(p, "Pemenang: " + r.name() + " (" + r.verb() + ")" + (mine ? " = kamu" : ""));
		return true;
	}

	private static void notice(ModConfig.Profile p, String word, int rgb) {
		if (p.notifyEnabled) {
			Notifier.show(word, rgb, p.notifyMs);
		}
	}

	// ------------------------------------------------------------------ simpan jawaban benar

	private static void checkConfirmation(ModConfig.Profile p, String text, long now) {
		if (lastKey.isEmpty() || now - lastKeyAt > p.confirmWindowMs || text.startsWith("<")) {
			return;
		}
		// 1) server mengumumkan jawabannya, mis. "Nama solved 4 x 8 (32) in 3.2 seconds"
		String revealed = findReveal(p, text);
		if (revealed != null && !revealed.isEmpty() && !lastKey.equals(resolvedKey)) {
			AnswerStore.put(lastKey, revealed);
			resolvedKey = lastKey;
			pending = null;
			info(p, "Jawaban tersimpan dari server: " + revealed);
			return;
		}
		// 2) server mengumumkan kita yang menang -> jawaban kita benar
		Pending pd = pending;
		if (pd == null || pd.key().equals(resolvedKey) || !"ai".equals(pd.source())) {
			return;
		}
		String me = myName(p);
		if (!me.isEmpty() && containsIgnoreCase(text, me)
			&& (containsAny(text, p.winKeywords) || containsAny(text, BUILTIN_WIN))) {
			AnswerStore.put(pd.key(), pd.answer());
			resolvedKey = pd.key();
			pending = null;
			info(p, "Jawaban benar tersimpan: " + pd.answer());
		}
	}

	private static String findReveal(ModConfig.Profile p, String text) {
		Matcher b = BUILTIN_REVEAL.matcher(text);
		if (b.find()) {
			return cleanReveal(b.group(1));
		}
		Pattern rp = revealPattern(p);
		if (rp != null) {
			Matcher m = rp.matcher(text);
			if (m.find() && m.groupCount() >= 1 && m.group(1) != null) {
				return cleanReveal(m.group(1));
			}
		}
		return null;
	}

	private static Pattern revealPattern(ModConfig.Profile p) {
		String src = p.revealRegex;
		if (src == null || src.isBlank()) {
			return null;
		}
		if (!src.equals(revealSrc)) {
			revealSrc = src;
			try {
				revealPat = Pattern.compile(src);
			} catch (PatternSyntaxException e) {
				revealPat = null;
			}
		}
		return revealPat;
	}

	private static String cleanReveal(String s) {
		String t = s.replace("**", "").replace("`", "").strip();
		t = t.replaceAll("^[\"']+|[\"']+$", "").replaceAll("[\\s.!?,;:]+$", "").strip();
		return t.length() > 80 ? "" : t;
	}

	// ------------------------------------------------------------------ util

	static String cleanAnswer(ModConfig.Profile p, String raw) {
		if (raw == null) {
			return "";
		}
		String s = raw.strip();
		int nl = s.indexOf('\n');
		if (nl >= 0) {
			s = s.substring(0, nl).strip();
		}
		s = s.replace("**", "").replace("`", "");
		s = s.replaceFirst("(?i)^(jawaban|answer)\\s*[:=-]\\s*", "");
		while (s.length() > 1 && ((s.startsWith("\"") && s.endsWith("\"")) || (s.startsWith("'") && s.endsWith("'")))) {
			s = s.substring(1, s.length() - 1).strip();
		}
		if (p.stripTrailingPunct) {
			s = s.replaceAll("[\\s.!?,;:]+$", "");
		}
		String[] w = s.split("\\s+");
		if (p.maxWords > 0 && w.length > p.maxWords) {
			s = String.join(" ", Arrays.copyOf(w, p.maxWords));
		}
		if ("LOWER".equalsIgnoreCase(p.answerCase)) {
			s = s.toLowerCase(Locale.ROOT);
		} else if ("UPPER".equalsIgnoreCase(p.answerCase)) {
			s = s.toUpperCase(Locale.ROOT);
		}
		return s.strip();
	}

	private static boolean isIgnored(ModConfig.Profile p, String category) {
		if (p.ignoredCategories == null || p.ignoredCategories.isBlank()) {
			return false;
		}
		for (String c : p.ignoredCategories.split(",")) {
			String t = c.strip();
			if (!t.isEmpty() && containsIgnoreCase(category, t)) {
				return true;
			}
		}
		return false;
	}

	private static boolean containsAny(String text, String csv) {
		if (csv == null) {
			return false;
		}
		for (String k : csv.split(",")) {
			String t = k.strip();
			if (!t.isEmpty() && containsIgnoreCase(text, t)) {
				return true;
			}
		}
		return false;
	}

	private static boolean containsIgnoreCase(String text, String part) {
		return indexOfIgnoreCase(text, part) >= 0;
	}

	private static int indexOfIgnoreCase(String text, String part) {
		int n = part.length();
		for (int i = 0; i + n <= text.length(); i++) {
			if (text.regionMatches(true, i, part, 0, n)) {
				return i;
			}
		}
		return -1;
	}

	/** IGN dari pengaturan; kalau kosong pakai nama akun yang sedang login. */
	private static String myName(ModConfig.Profile p) {
		String n = p.ign == null ? "" : p.ign.strip();
		if (!n.isEmpty()) {
			return n;
		}
		LocalPlayer pl = Minecraft.getInstance().player;
		return pl == null ? "" : pl.getName().getString();
	}

	private static void runOnMain(Runnable r) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.isSameThread()) {
			r.run();
		} else {
			mc.execute(r);
		}
	}

	private static void info(ModConfig.Profile p, String msg) {
		if (!p.showInfoInChat) {
			return;
		}
		LocalPlayer pl = Minecraft.getInstance().player;
		if (pl != null) {
			pl.sendSystemMessage(Fmt.info(msg));
		}
	}

	private static void debug(ModConfig.Profile p, String msg) {
		if (p.debug) {
			info(p, msg);
		}
	}
}
