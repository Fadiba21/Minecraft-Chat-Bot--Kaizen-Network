package com.fadiba.chatgameai;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;

import java.util.Arrays;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/** Mendeteksi "Chat Game" di chat server lalu menjawab otomatis lewat akun client. */
public final class ChatGameEngine {
	private static final Pattern TAG = Pattern.compile("^[^\\[\\]]{0,12}\\[([^\\]]{1,40})\\]\\s*(\\S.*)$");
	private static final Pattern TAG_START = Pattern.compile("^\\[([^\\]]{1,40})\\]\\s*(\\S.*)$");
	private static final Pattern MATH_CAT = Pattern.compile("(?i)mat|math|hitung|calc|angka|number|aritm|tambah|add|sum|jumlah");
	private static final Pattern SCRAMBLE = Pattern.compile("(?i)pecahkan|acak|scramble|unscramble|anagram|susun|sandi|cipher|key\\s*:");
	private static final String INFO_PREFIX = "[ChatGameAI] ";

	private record Pending(String key, String answer, String source) {
	}

	private static boolean waiting;
	private static long deadline;
	private static int lines;

	private static String lastText = "";
	private static long lastTextAt;

	private static String lastKey = "";
	private static long lastKeyAt;
	private static String resolvedKey = "";
	private static long lastAnswerAt;
	private static int round;
	private static Pending pending;

	private static String revealSrc;
	private static Pattern revealPat;

	private ChatGameEngine() {
	}

	// ------------------------------------------------------------------ pesan masuk

	public static void onMessage(Component component) {
		if (!ModConfig.isEnabled()) {
			return;
		}
		ModConfig.Profile p = ModConfig.active();
		String text = component.getString().replaceAll("§.", "").strip();
		if (text.isEmpty() || text.startsWith(INFO_PREFIX.strip())) {
			return;
		}
		long now = System.currentTimeMillis();
		if (text.equals(lastText) && now - lastTextAt < 100) {
			return; // pesan ganda dari dua jalur event
		}
		lastText = text;
		lastTextAt = now;

		checkConfirmation(p, text, now);

		String kw = p.triggerKeyword == null ? "" : p.triggerKeyword.strip();
		int kwIdx = kw.isEmpty() ? -1 : indexOfIgnoreCase(text, kw);
		boolean playerChat = p.ignorePlayerChat && text.startsWith("<");

		if (kwIdx >= 0 && !playerChat) {
			waiting = true;
			deadline = now + p.captureTimeoutMs;
			lines = 0;
			String rem = text.substring(kwIdx + kw.length()).replaceFirst("^[\\]\\s:>»|\\-*=~]+", "");
			if (handleCandidate(p, rem, now)) {
				waiting = false;
			}
			return;
		}

		if (waiting) {
			if (now > deadline) {
				waiting = false;
				return;
			}
			if (playerChat) {
				return;
			}
			if (handleCandidate(p, text, now)) {
				waiting = false;
			} else {
				debug(p, "Baris diabaikan: " + text);
				if (++lines >= p.maxLinesAfterTrigger) {
					waiting = false;
				}
			}
		}
	}

	/** @return true jika baris ini dikenali sebagai soal. */
	private static boolean handleCandidate(ModConfig.Profile p, String line, long now) {
		if (line == null || line.isBlank()) {
			return false;
		}
		Matcher m = TAG.matcher(line);
		if (m.find()) {
			String cat = m.group(1).strip();
			String q = m.group(2).strip();
			for (int i = 0; i < 2; i++) {
				Matcher m2 = TAG_START.matcher(q);
				if (m2.matches()) {
					cat = m2.group(1).strip();
					q = m2.group(2).strip();
				} else {
					break;
				}
			}
			if (cat.equalsIgnoreCase(p.triggerKeyword)) {
				cat = "Umum";
			}
			process(p, cat, q, now);
			return true;
		}
		String plain = line.strip();
		// soal tanpa tag: "The first to type 'sgo' wins!"
		if (LocalSolver.typeAnswer(plain) != null) {
			process(p, "Ketik", plain, now);
			return true;
		}
		// soal hitungan tanpa tag
		if (p.detectMathWithoutTag && MathSolver.looksLikeMath(plain)) {
			process(p, "Matematika", plain, now);
			return true;
		}
		return false;
	}

	// ------------------------------------------------------------------ menjawab

	private static void process(ModConfig.Profile p, String category, String question, long now) {
		String key = AnswerStore.norm(question);
		if (key.isEmpty() || isIgnored(p, category)) {
			return;
		}
		if (key.equals(lastKey) && now - lastKeyAt < 3000) {
			return; // soal yang sama baru saja diproses
		}
		if (now - lastAnswerAt < p.cooldownMs) {
			debug(p, "Cooldown, soal dilewati");
			return;
		}
		lastKey = key;
		lastKeyAt = now;
		pending = null;
		int myRound = ++round;
		debug(p, "Soal [" + category + "] " + question);

		if (p.localMathSolver) {
			LocalSolver.Result r = LocalSolver.solve(category, question);
			if (r != null) {
				reply(p, r.answer(), r.source(), classify(category, question, r.source()), key, myRound, now);
				return;
			}
		}
		if (p.useCache) {
			String cached = AnswerStore.get(key);
			if (cached != null) {
				reply(p, cached, "cache", classify(category, question, "cache"), key, myRound, now);
				return;
			}
		}

		ModConfig.DelayType type = classify(category, question, "ai");
		GeminiClient.ask(p, category, question).whenComplete((ans, err) -> runOnMain(() -> {
			if (myRound != round) {
				return;
			}
			if (err != null) {
				Throwable t = err instanceof CompletionException && err.getCause() != null ? err.getCause() : err;
				String msg = t.getMessage() != null ? t.getMessage() : t.getClass().getSimpleName();
				info(p, "AI gagal: " + msg);
				return;
			}
			reply(p, ans, "ai", type, key, myRound, now);
		}));
	}

	/** Tentukan tipe soal untuk memilih pengaturan delay. */
	private static ModConfig.DelayType classify(String category, String question, String source) {
		switch (source) {
			case "ketik":
				return ModConfig.DelayType.TYPE;
			case "sandi":
				return ModConfig.DelayType.SCRAMBLE;
			case "hitung":
				return ModConfig.DelayType.MATH;
			default:
				break;
		}
		String cat = category == null ? "" : category;
		if (LocalSolver.typeAnswer(question) != null) {
			return ModConfig.DelayType.TYPE;
		}
		if (MATH_CAT.matcher(cat).find()) {
			return ModConfig.DelayType.MATH;
		}
		if (SCRAMBLE.matcher(cat).find() || SCRAMBLE.matcher(question).find()) {
			return ModConfig.DelayType.SCRAMBLE;
		}
		return ModConfig.DelayType.GENERAL;
	}

	private static void reply(ModConfig.Profile p, String raw, String source, ModConfig.DelayType type,
							  String key, int myRound, long startedAt) {
		// jawaban soal "ketik" harus persis, jadi tidak dibersihkan/diubah hurufnya
		String answer = "ketik".equals(source) ? (raw == null ? "" : raw.strip()) : cleanAnswer(p, raw);
		if (answer.isEmpty()) {
			return;
		}
		int delay = p.delay(type).resolve();

		Runnable send = () -> {
			if (myRound != round || !ModConfig.isEnabled()) {
				return;
			}
			LocalPlayer player = Minecraft.getInstance().player;
			if (player == null) {
				return;
			}
			player.connection.sendChat(answer);
			long t = System.currentTimeMillis();
			lastAnswerAt = t;
			pending = new Pending(key, answer, source);
			if ("ai".equals(source) && p.saveUnverified) {
				AnswerStore.put(key, answer);
			}
			info(p, "Jawab (" + source + ", " + type.label + ", total " + (t - startedAt) + " ms, delay " + delay + " ms): " + answer);
		};

		if (delay <= 0) {
			runOnMain(send);
		} else {
			CompletableFuture.runAsync(() -> runOnMain(send), CompletableFuture.delayedExecutor(delay, TimeUnit.MILLISECONDS));
		}
	}

	// ------------------------------------------------------------------ simpan jawaban benar

	private static void checkConfirmation(ModConfig.Profile p, String text, long now) {
		if (lastKey.isEmpty() || now - lastKeyAt > p.confirmWindowMs || text.startsWith("<")) {
			return;
		}
		Pattern rp = revealPattern(p);
		if (rp != null) {
			Matcher m = rp.matcher(text);
			if (m.find()) {
				String ans = cleanReveal(m.group(1));
				if (!ans.isEmpty()) {
					AnswerStore.put(lastKey, ans);
					resolvedKey = lastKey;
					pending = null;
					info(p, "Disimpan dari server: " + ans);
					return;
				}
			}
		}
		Pending pd = pending;
		// hanya jawaban AI yang perlu disimpan (hitung/ketik/sandi sudah dihitung lokal)
		if (pd == null || pd.key().equals(resolvedKey) || !"ai".equals(pd.source())) {
			return;
		}
		String me = playerName();
		if (me != null && containsIgnoreCase(text, me) && containsAny(text, p.winKeywords)) {
			AnswerStore.put(pd.key(), pd.answer());
			resolvedKey = pd.key();
			pending = null;
			info(p, "Jawaban benar disimpan: " + pd.answer());
		}
	}

	private static Pattern revealPattern(ModConfig.Profile p) {
		String src = p.revealRegex;
		if (src == null || src.isBlank()) {
			return null;
		}
		if (!src.equals(revealSrc)) {
			revealSrc = src;
			try {
				revealPat = Pattern.compile(src);
			} catch (PatternSyntaxException e) {
				revealPat = null;
			}
		}
		return revealPat;
	}

	private static String cleanReveal(String s) {
		String t = s.replace("**", "").replace("`", "").strip();
		t = t.replaceAll("^[\"']+|[\"']+$", "").replaceAll("[\\s.!?,;:]+$", "").strip();
		return t.length() > 80 ? "" : t;
	}

	// ------------------------------------------------------------------ util

	static String cleanAnswer(ModConfig.Profile p, String raw) {
		if (raw == null) {
			return "";
		}
		String s = raw.strip();
		int nl = s.indexOf('\n');
		if (nl >= 0) {
			s = s.substring(0, nl).strip();
		}
		s = s.replace("**", "").replace("`", "");
		s = s.replaceFirst("(?i)^(jawaban|answer)\\s*[:=-]\\s*", "");
		while (s.length() > 1 && ((s.startsWith("\"") && s.endsWith("\"")) || (s.startsWith("'") && s.endsWith("'")))) {
			s = s.substring(1, s.length() - 1).strip();
		}
		if (p.stripTrailingPunct) {
			s = s.replaceAll("[\\s.!?,;:]+$", "");
		}
		String[] w = s.split("\\s+");
		if (p.maxWords > 0 && w.length > p.maxWords) {
			s = String.join(" ", Arrays.copyOf(w, p.maxWords));
		}
		if ("LOWER".equalsIgnoreCase(p.answerCase)) {
			s = s.toLowerCase(Locale.ROOT);
		} else if ("UPPER".equalsIgnoreCase(p.answerCase)) {
			s = s.toUpperCase(Locale.ROOT);
		}
		return s.strip();
	}

	private static boolean isIgnored(ModConfig.Profile p, String category) {
		if (p.ignoredCategories == null || p.ignoredCategories.isBlank()) {
			return false;
		}
		for (String c : p.ignoredCategories.split(",")) {
			String t = c.strip();
			if (!t.isEmpty() && containsIgnoreCase(category, t)) {
				return true;
			}
		}
		return false;
	}

	private static boolean containsAny(String text, String csv) {
		if (csv == null) {
			return false;
		}
		for (String k : csv.split(",")) {
			String t = k.strip();
			if (!t.isEmpty() && containsIgnoreCase(text, t)) {
				return true;
			}
		}
		return false;
	}

	private static boolean containsIgnoreCase(String text, String part) {
		return indexOfIgnoreCase(text, part) >= 0;
	}

	private static int indexOfIgnoreCase(String text, String part) {
		int n = part.length();
		for (int i = 0; i + n <= text.length(); i++) {
			if (text.regionMatches(true, i, part, 0, n)) {
				return i;
			}
		}
		return -1;
	}

	private static String playerName() {
		LocalPlayer pl = Minecraft.getInstance().player;
		return pl == null ? null : pl.getName().getString();
	}

	private static void runOnMain(Runnable r) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.isSameThread()) {
			r.run();
		} else {
			mc.execute(r);
		}
	}

	private static void info(ModConfig.Profile p, String msg) {
		if (!p.showInfoInChat) {
			return;
		}
		LocalPlayer pl = Minecraft.getInstance().player;
		if (pl != null) {
			pl.sendSystemMessage(Component.literal(INFO_PREFIX + msg));
		}
	}

	private static void debug(ModConfig.Profile p, String msg) {
		if (p.debug) {
			info(p, msg);
		}
	}
}
