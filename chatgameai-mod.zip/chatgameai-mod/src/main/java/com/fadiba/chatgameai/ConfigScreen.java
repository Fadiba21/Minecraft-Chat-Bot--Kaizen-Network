package com.fadiba.chatgameai;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** Layar pengaturan EthenaLabs AI (dibuka dari Mod Menu). Tab di atas untuk pindah halaman. */
public final class ConfigScreen extends Screen {
	private static final int MAX_W = 320;
	private static final int TAB_Y = 18;
	private static final int CONTENT_Y = 48;
	private static final int PAGE_DELAY = 3;
	private static final int PAGE_DATA = 6;
	private static final String[] TABS = {"Umum", "Deteksi", "Jawab", "Delay", "Format", "AI", "Data"};
	private static final String[] CASES = {"ASIS", "LOWER", "UPPER"};

	private static final int COL_ACCENT = 0xFF5CCBFF;
	private static final int COL_LABEL = 0xA0A0A0;

	/** Tipe soal yang sedang dipilih di halaman Delay (diingat antar halaman). */
	private static int delayTypeIdx = 0;

	private record Label(Component text, int x, int y) {
	}

	private final Screen parent;
	private final int page;
	private final List<Label> labels = new ArrayList<>();
	private int cw;
	private int x0;
	private int y;
	private int tabW;

	private String newProfile = "";
	private String manualQ = "";
	private String manualA = "";
	private boolean confirmClear;

	public ConfigScreen(Screen parent, int page) {
		super(Component.literal(Fmt.NAME));
		this.parent = parent;
		this.page = Math.max(0, Math.min(TABS.length - 1, page));
	}

	@Override
	protected void init() {
		labels.clear();
		cw = Math.min(MAX_W, this.width - 16);
		x0 = (this.width - cw) / 2;
		y = CONTENT_Y;
		ModConfig.Profile p = ModConfig.active();

		addTabs();
		switch (page) {
			case 0 -> pageGeneral(p);
			case 1 -> pageDetect(p);
			case 2 -> pageAnswer(p);
			case PAGE_DELAY -> pageDelay(p);
			case 4 -> pageFormat(p);
			case 5 -> pageAi(p);
			default -> pageData(p);
		}
		addRenderableWidget(Button.builder(Component.literal("Selesai"), b -> onClose())
			.bounds(this.width / 2 - 60, this.height - 24, 120, 20).build());
	}

	// ------------------------------------------------------------------ halaman

	private void pageGeneral(ModConfig.Profile p) {
		section("Profil");
		List<String> names = ModConfig.names();
		button("Profil aktif: " + ModConfig.activeName() + "  (klik untuk ganti)", cw, btn -> {
			int i = names.indexOf(ModConfig.activeName());
			ModConfig.setActive(names.get((i + 1) % names.size()));
			navigate(0);
		});

		label("Nama profil baru (disalin dari profil aktif)");
		EditBox box = new EditBox(this.font, x0, y, cw - 90, 18, Component.literal("Nama profil"));
		box.setMaxLength(32);
		box.setValue(newProfile);
		box.setResponder(s -> newProfile = s);
		addRenderableWidget(box);
		addRenderableWidget(Button.builder(Component.literal("Tambah"), btn -> {
			if (ModConfig.addProfile(newProfile)) {
				navigate(0);
			}
		}).bounds(x0 + cw - 86, y - 1, 86, 20).build());
		y += 25;

		int half = cw / 2 - 2;
		addRenderableWidget(Button.builder(Component.literal("Reset profil ini"), btn -> {
			ModConfig.resetActive();
			navigate(0);
		}).bounds(x0, y, half, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Hapus profil ini"), btn -> {
			if (ModConfig.deleteActive()) {
				navigate(0);
			}
		}).bounds(x0 + cw - half, y, half, 20).build());
		y += 28;

		section("Saklar");
		toggle("Mod aktif (global, semua profil)", ModConfig::isEnabled, ModConfig::setEnabled);
		toggle("Info jawaban di chat (lokal)", () -> p.showInfoInChat, v -> p.showInfoInChat = v);
		toggle("Mode debug", () -> p.debug, v -> p.debug = v);
		label("Keybind ON/OFF: Options > Controls > Key Binds > EthenaLabs AI (default K)");
	}

	private void pageDetect(ModConfig.Profile p) {
		field("Kata kunci pemicu (di baris pertama)", () -> p.triggerKeyword, v -> p.triggerKeyword = v, 64);
		intField("Maks baris dibaca setelah pemicu", () -> p.maxLinesAfterTrigger, v -> p.maxLinesAfterTrigger = v, 1, 20);
		intField("Batas waktu menunggu soal (ms)", () -> p.captureTimeoutMs, v -> p.captureTimeoutMs = v, 500, 30000);
		toggle("Abaikan chat pemain sebagai pemicu", () -> p.ignorePlayerChat, v -> p.ignorePlayerChat = v);
		toggle("Deteksi soal hitungan tanpa tanda [..]", () -> p.detectMathWithoutTag, v -> p.detectMathWithoutTag = v);
		field("Kategori diabaikan (pisah koma)", () -> p.ignoredCategories, v -> p.ignoredCategories = v, 200);
	}

	private void pageAnswer(ModConfig.Profile p) {
		toggle("Solver lokal tanpa AI (hitung, ketik, sandi)", () -> p.localMathSolver, v -> p.localMathSolver = v);
		toggle("Pakai cache jawaban tersimpan", () -> p.useCache, v -> p.useCache = v);
		toggle("Simpan jawaban AI tanpa konfirmasi benar", () -> p.saveUnverified, v -> p.saveUnverified = v);
		field("Kata konfirmasi benar (pisah koma)", () -> p.winKeywords, v -> p.winKeywords = v, 200);
		intField("Cooldown antar jawaban (ms)", () -> p.cooldownMs, v -> p.cooldownMs = v, 0, 60000);
	}

	private void pageDelay(ModConfig.Profile p) {
		ModConfig.DelayType[] types = ModConfig.DelayType.values();
		ModConfig.DelayType t = types[delayTypeIdx % types.length];
		ModConfig.Delay d = p.delay(t);

		section("Tipe soal");
		button(t.label + "   (klik untuk ganti tipe)", cw, btn -> {
			delayTypeIdx = (delayTypeIdx + 1) % types.length;
			navigate(PAGE_DELAY);
		});

		section("Mode delay");
		addRenderableWidget(Button.builder(
			Component.literal("Random delay: ").append(Fmt.onOff(d.random)), btn -> {
				d.random = !d.random;
				navigate(PAGE_DELAY); // bangun ulang supaya slider yang tidak aktif ikut berubah
			}).bounds(x0, y, cw, 20).build());
		y += 24;

		slider("Delay manual", d.fixedMs, v -> d.fixedMs = v, !d.random);
		slider("Random minimum", d.minMs, v -> {
			d.minMs = v;
			if (d.maxMs < v) {
				d.maxMs = v;
			}
		}, d.random);
		slider("Random maksimum", d.maxMs, v -> {
			d.maxMs = v;
			if (d.minMs > v) {
				d.minMs = v;
			}
		}, d.random);

		y += 2;
		String now = d.random
			? "Aktif: random " + sec(Math.min(d.minMs, d.maxMs)) + " - " + sec(Math.max(d.minMs, d.maxMs))
			: "Aktif: manual " + sec(d.fixedMs);
		labels.add(new Label(Fmt.colored(now, Fmt.GREEN), x0, y));
		y += 12;
		label("Delay = jeda sebelum jawaban dikirim, setelah jawaban siap.");
		label("Random ON: slider manual mati. Tiap tipe soal punya pengaturan sendiri.");
	}

	private void pageFormat(ModConfig.Profile p) {
		intField("Maks kata jawaban (0 = tanpa batas)", () -> p.maxWords, v -> p.maxWords = v, 0, 20);
		cycle("Huruf jawaban", () -> p.answerCase, v -> p.answerCase = v);
		toggle("Hapus tanda baca di akhir jawaban", () -> p.stripTrailingPunct, v -> p.stripTrailingPunct = v);
		intField("Jendela konfirmasi jawaban (ms)", () -> p.confirmWindowMs, v -> p.confirmWindowMs = v, 1000, 120000);
		field("Regex jawaban yang diumumkan server", () -> p.revealRegex, v -> p.revealRegex = v, 400);
	}

	private void pageAi(ModConfig.Profile p) {
		field("API key Gemini", () -> p.apiKey, v -> p.apiKey = v, 200);
		field("Model", () -> p.model, v -> p.model = v, 80);
		field("Base URL API", () -> p.apiBase, v -> p.apiBase = v, 200);
		doubleField("Temperature (0.0 - 2.0)", () -> p.temperature, v -> p.temperature = v);
		intField("Maks token keluaran", () -> p.maxOutputTokens, v -> p.maxOutputTokens = v, 8, 4096);
		intField("Timeout HTTP (ms)", () -> p.httpTimeoutMs, v -> p.httpTimeoutMs = v, 1000, 60000);
	}

	private void pageData(ModConfig.Profile p) {
		field("Prompt sistem AI", () -> p.systemPrompt, v -> p.systemPrompt = v, 2000);
		section("Data jawaban");
		label("Tersimpan: " + AnswerStore.size() + " soal  (config/ethenalabs-answers.txt)");
		button(confirmClear ? "Yakin? Klik lagi untuk hapus semua" : "Hapus semua data jawaban", cw, btn -> {
			if (confirmClear) {
				AnswerStore.clear();
				navigate(PAGE_DATA);
			} else {
				confirmClear = true;
				btn.setMessage(Component.literal("Yakin? Klik lagi untuk hapus semua"));
			}
		});
		textBox("Tambah manual: soal (persis seperti di chat)", () -> manualQ, v -> manualQ = v, 300);
		textBox("Tambah manual: jawaban", () -> manualA, v -> manualA = v, 100);
		button("Simpan jawaban manual", cw, btn -> {
			if (!manualQ.isBlank() && !manualA.isBlank()) {
				AnswerStore.put(AnswerStore.norm(manualQ), manualA.strip());
				navigate(PAGE_DATA);
			}
		});
	}

	// ------------------------------------------------------------------ navigasi

	private void addTabs() {
		int n = TABS.length;
		int gap = 2;
		tabW = (cw - gap * (n - 1)) / n;
		for (int i = 0; i < n; i++) {
			final int target = i;
			Button b = Button.builder(Component.literal(TABS[i]), btn -> navigate(target))
				.bounds(x0 + i * (tabW + gap), TAB_Y, tabW, 20).build();
			b.active = i != page; // tab aktif tampak "tertekan"
			addRenderableWidget(b);
		}
	}

	private void navigate(int newPage) {
		ModConfig.save();
		this.minecraft.gui.setScreen(new ConfigScreen(parent, newPage));
	}

	@Override
	public void onClose() {
		ModConfig.save();
		this.minecraft.gui.setScreen(parent);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);

		// header: judul bernuansa pelangi di kiri, status ON/OFF + profil di kanan
		graphics.text(this.font, Fmt.title(), x0, 5, 0xFFFFFFFF, true);
		String right = ModConfig.isEnabled() ? "✔ ON" : "✖ OFF";
		Component status = Fmt.statusShort(ModConfig.isEnabled());
		String prof = "  [" + ModConfig.activeName() + "]";
		int rw = this.font.width(right) + this.font.width(prof);
		graphics.text(this.font, status, x0 + cw - rw, 5, 0xFFFFFFFF, true);
		graphics.text(this.font, Fmt.colored(prof, COL_LABEL), x0 + cw - this.font.width(prof), 5, 0xFFFFFFFF, false);

		// garis di bawah tab + penanda tab aktif
		graphics.fill(x0, TAB_Y + 22, x0 + cw, TAB_Y + 23, 0x55FFFFFF);
		int ux = x0 + page * (tabW + 2);
		graphics.fill(ux, TAB_Y + 21, ux + tabW, TAB_Y + 24, COL_ACCENT);

		for (Label l : labels) {
			graphics.text(this.font, l.text(), l.x(), l.y(), 0xFFFFFFFF, false);
		}
	}

	// ------------------------------------------------------------------ pembantu widget

	private void section(String text) {
		labels.add(new Label(Fmt.section(text), x0, y));
		y += 12;
	}

	private void label(String text) {
		labels.add(new Label(Fmt.colored(text, COL_LABEL), x0, y));
		y += 10;
	}

	private void button(String text, int width, Button.OnPress onPress) {
		addRenderableWidget(Button.builder(Component.literal(text), onPress).bounds(x0, y, width, 20).build());
		y += 24;
	}

	private void slider(String name, int initialMs, IntConsumer set, boolean active) {
		MsSlider s = new MsSlider(x0, y, cw, name, initialMs, set);
		s.active = active;
		addRenderableWidget(s);
		y += 24;
	}

	private void toggle(String name, BooleanSupplier get, Consumer<Boolean> set) {
		Button b = Button.builder(toggleText(name, get.getAsBoolean()), btn -> {
			boolean v = !get.getAsBoolean();
			set.accept(v);
			btn.setMessage(toggleText(name, v));
		}).bounds(x0, y, cw, 20).build();
		addRenderableWidget(b);
		y += 24;
	}

	private static Component toggleText(String name, boolean v) {
		return Component.literal(name + ": ").append(Fmt.onOff(v));
	}

	private void cycle(String name, Supplier<String> get, Consumer<String> set) {
		Button b = Button.builder(Component.literal(name + ": " + get.get()), btn -> {
			int i = 0;
			for (int k = 0; k < CASES.length; k++) {
				if (CASES[k].equalsIgnoreCase(get.get())) {
					i = k;
				}
			}
			String next = CASES[(i + 1) % CASES.length];
			set.accept(next);
			btn.setMessage(Component.literal(name + ": " + next));
		}).bounds(x0, y, cw, 20).build();
		addRenderableWidget(b);
		y += 24;
	}

	private void field(String name, Supplier<String> get, Consumer<String> set, int max) {
		textBox(name, get, set, max);
	}

	private void textBox(String name, Supplier<String> get, Consumer<String> set, int max) {
		label(name);
		EditBox box = new EditBox(this.font, x0, y, cw, 18, Component.literal(name));
		box.setMaxLength(max);
		box.setValue(get.get());
		box.setResponder(set);
		addRenderableWidget(box);
		y += 21;
	}

	private void intField(String name, IntSupplier get, IntConsumer set, int min, int max) {
		textBox(name + "  [" + min + "-" + max + "]", () -> String.valueOf(get.getAsInt()), s -> {
			try {
				int v = Integer.parseInt(s.strip());
				if (v >= min && v <= max) {
					set.accept(v);
				}
			} catch (NumberFormatException ignored) {
				// biarkan nilai lama sampai input valid
			}
		}, 9);
	}

	private void doubleField(String name, Supplier<Double> get, Consumer<Double> set) {
		textBox(name, () -> String.valueOf(get.get()), s -> {
			try {
				double v = Double.parseDouble(s.strip().replace(',', '.'));
				if (v >= 0.0 && v <= 2.0) {
					set.accept(v);
				}
			} catch (NumberFormatException ignored) {
				// biarkan nilai lama sampai input valid
			}
		}, 8);
	}

	private static String sec(int ms) {
		return String.format(Locale.ROOT, "%.1f s", ms / 1000.0);
	}

	/** Slider detik: 0.1 s - 10 s, kelipatan 0.1 (disimpan dalam ms). */
	private static final class MsSlider extends AbstractSliderButton {
		private static final int MIN = ModConfig.DELAY_MIN;
		private static final int MAX = ModConfig.DELAY_MAX;
		private static final int STEP = 100;

		private final String name;
		private final IntConsumer set;

		MsSlider(int x, int y, int width, String name, int initialMs, IntConsumer set) {
			super(x, y, width, 20, Component.empty(), toValue(initialMs));
			this.name = name;
			this.set = set;
			updateMessage();
		}

		private static double toValue(int ms) {
			int c = Math.max(MIN, Math.min(MAX, ms));
			return (c - MIN) / (double) (MAX - MIN);
		}

		private int ms() {
			int steps = (int) Math.round(this.value * (MAX - MIN) / STEP);
			return Math.max(MIN, Math.min(MAX, MIN + steps * STEP));
		}

		@Override
		protected void updateMessage() {
			setMessage(Component.literal(name + ": " + sec(ms())));
		}

		@Override
		protected void applyValue() {
			set.accept(ms());
		}
	}
}
