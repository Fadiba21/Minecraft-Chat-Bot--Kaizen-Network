package com.fadiba.chatgameai;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletionException;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** Layar pengaturan Chatgpt-oss (dibuka dari Mod Menu). Tab berikon di atas, isi 2 kolom. */
public final class ConfigScreen extends Screen {
	private static final int MAX_W = 440;
	private static final int GAP = 6;
	private static final int TAB_Y = 18;
	private static final int CONTENT_Y = 50;
	private static final int ROW = 24;
	private static final int FIELD_ROW = 32;

	private static final int P_GENERAL = 0;
	private static final int P_NOTIFY = 1;
	private static final int P_DETECT = 2;
	private static final int P_ANSWER = 3;
	private static final int P_DELAY = 4;
	private static final int P_FORMAT = 5;
	private static final int P_AI = 6;
	private static final int P_DATA = 7;
	private static final int P_STATS = 8;

	private static final String[] ICONS = {"⚙", "✉", "◎", "✔", "◷", "✎", "★", "☰", "∑"};
	private static final String[] SHORT = {"Umum", "Notif", "Soal", "Jawab", "Delay", "Teks", "AI", "Data", "Stat"};
	private static final String[] FULL = {
		"Profil & Saklar", "Identitas & Notifikasi", "Deteksi Chat Game", "Cara Menjawab", "Delay Kirim",
		"Format Jawaban", "AI (Gemini)", "Data & Prompt", "Statistik"
	};
	private static final String[] TYPE_SHORT = {"Biasa", "Matematika", "Ketik", "Acak/Sandi"};
	private static final String[] CASES = {"ASIS", "LOWER", "UPPER"};

	/** Tipe soal yang sedang dipilih di halaman Delay (diingat antar halaman). */
	private static int delayTypeIdx = 0;
	private static volatile String aiTest = "";
	private static volatile boolean aiTestOk = true;

	private record Txt(Component text, int x, int y) {
	}

	private record Section(String text, int x, int y) {
	}

	private final Screen parent;
	private final int page;
	private final List<Txt> labels = new ArrayList<>();
	private final List<Section> sections = new ArrayList<>();
	private int cw;
	private int x0;
	private int y;
	private int col;
	private int rowH;
	private int tabW;
	private int testY;

	private String newProfile = "";

	public ConfigScreen(Screen parent, int page) {
		super(Component.literal(Fmt.NAME));
		this.parent = parent;
		this.page = Math.max(0, Math.min(ICONS.length - 1, page));
	}

	@Override
	protected void init() {
		labels.clear();
		sections.clear();
		col = 0;
		rowH = 0;
		cw = Math.min(MAX_W, this.width - 12);
		x0 = (this.width - cw) / 2;
		y = CONTENT_Y;
		ModConfig.Profile p = ModConfig.active();

		addTabs();
		section(ICONS[page] + " " + FULL[page]);
		switch (page) {
			case P_GENERAL -> pageGeneral(p);
			case P_NOTIFY -> pageNotify(p);
			case P_DETECT -> pageDetect(p);
			case P_ANSWER -> pageAnswer(p);
			case P_DELAY -> pageDelay(p);
			case P_FORMAT -> pageFormat(p);
			case P_AI -> pageAi(p);
			case P_DATA -> pageData(p);
			default -> pageStats();
		}
		endRow();
		addRenderableWidget(Button.builder(Component.literal("✔ Selesai"), b -> onClose())
			.bounds(this.width / 2 - 60, this.height - 24, 120, 20).build());
	}

	// ------------------------------------------------------------------ halaman

	private void pageGeneral(ModConfig.Profile p) {
		List<String> names = ModConfig.names();
		button("Profil aktif: " + ModConfig.activeName() + "   (klik: ganti)", true, btn -> {
			int i = names.indexOf(ModConfig.activeName());
			ModConfig.setActive(names.get((i + 1) % names.size()));
			navigate(P_GENERAL);
		});

		int[] s = slot(true, FIELD_ROW);
		labels.add(new Txt(Fmt.colored("Nama profil baru (salinan profil aktif)", Fmt.GRAY), s[0], s[2]));
		EditBox box = new EditBox(this.font, s[0], s[2] + 10, s[1] - 82, 18, Component.literal("Nama profil"));
		box.setMaxLength(32);
		box.setValue(newProfile);
		box.setResponder(v -> newProfile = v);
		addRenderableWidget(box);
		addRenderableWidget(Button.builder(Component.literal("✚ Tambah"), btn -> {
			if (ModConfig.addProfile(newProfile)) {
				newProfile = "";
				navigate(P_GENERAL);
			}
		}).bounds(s[0] + s[1] - 78, s[2] + 9, 78, 20).build());

		button("↺ Reset profil ini", false, btn -> {
			ModConfig.resetActive();
			navigate(P_GENERAL);
		});
		button("✖ Hapus profil ini", false, btn -> {
			if (ModConfig.deleteActive()) {
				navigate(P_GENERAL);
			}
		});

		section("⚡ Saklar");
		toggle("Mod aktif (semua profil)", ModConfig::isEnabled, ModConfig::setEnabled, false);
		toggle("Info jawaban di chat", () -> p.showInfoInChat, v -> p.showInfoInChat = v, false);
		toggle("Mode debug", () -> p.debug, v -> p.debug = v, false);
		endRow();
		note("Keybind ON/OFF: Options > Controls > Key Binds > Chatgpt-oss (default K)");
	}

	private void pageNotify(ModConfig.Profile p) {
		textBox("Nama in-game kamu (IGN)", () -> p.ign, v -> p.ign = v, 32, true);
		note("Pemenang = IGN ini -> Terjawab. Pemenang orang lain -> Telat.");

		section("✉ Action bar");
		toggle("Notifikasi Terjawab/Telat", () -> p.notifyEnabled, v -> p.notifyEnabled = v, false);
		slider("Lama tampil", p.notifyMs, ModConfig.NOTIFY_MIN, ModConfig.NOTIFY_MAX, 500, v -> p.notifyMs = v, true, false);
		button("▶ Tes: Terjawab", false, btn -> Notifier.show("Terjawab", Fmt.ANSWERED, p.notifyMs));
		button("▶ Tes: Telat", false, btn -> Notifier.show("Telat", Fmt.LATE, p.notifyMs));
		endRow();
		note("Tombol tes hanya terlihat saat kamu sedang di dalam dunia/server.");
	}

	private void pageDetect(ModConfig.Profile p) {
		textBox("Kata pemicu", () -> p.triggerKeyword, v -> p.triggerKeyword = v, 64, false);
		textBox("Kategori diabaikan (koma)", () -> p.ignoredCategories, v -> p.ignoredCategories = v, 200, false);
		intField("Maks baris soal [1-20]", () -> p.maxLinesAfterTrigger, v -> p.maxLinesAfterTrigger = v, 1, 20, false);
		intField("Batas tunggu soal ms [500-30000]", () -> p.captureTimeoutMs, v -> p.captureTimeoutMs = v, 500, 30000, false);
		toggle("Abaikan chat pemain", () -> p.ignorePlayerChat, v -> p.ignorePlayerChat = v, false);
		toggle("Hitungan tanpa tanda [..]", () -> p.detectMathWithoutTag, v -> p.detectMathWithoutTag = v, false);
		textBox("Kata kerja pengumuman pemenang (koma)", () -> p.winVerbs, v -> p.winVerbs = v, 200, true);
		note("Contoh: \"Nama typed 'x' in 3.6 seconds\" atau \"Nama solved 4 x 8 (32) in 3 seconds\".");
	}

	private void pageAnswer(ModConfig.Profile p) {
		toggle("Solver lokal (tanpa AI)", () -> p.localMathSolver, v -> p.localMathSolver = v, false);
		toggle("Pakai cache jawaban", () -> p.useCache, v -> p.useCache = v, false);
		toggle("Simpan AI tanpa konfirmasi", () -> p.saveUnverified, v -> p.saveUnverified = v, false);
		endRow();

		section("☰ Jenis soal yang dijawab");
		toggle("Pertanyaan biasa", () -> p.answerGeneral, v -> p.answerGeneral = v, false);
		toggle("Matematika", () -> p.answerMath, v -> p.answerMath = v, false);
		toggle("Ketik 'first to type'", () -> p.answerType, v -> p.answerType = v, false);
		toggle("Pecahkan/sandi", () -> p.answerScramble, v -> p.answerScramble = v, false);
		endRow();
		note("Matikan jenis soal yang tidak mau dijawab otomatis.");
	}

	private void pageDelay(ModConfig.Profile p) {
		ModConfig.DelayType[] types = ModConfig.DelayType.values();
		ModConfig.DelayType t = types[delayTypeIdx % types.length];
		ModConfig.Delay d = p.delay(t);

		button("Tipe soal: " + TYPE_SHORT[t.ordinal()] + "  ▸", false, btn -> {
			delayTypeIdx = (delayTypeIdx + 1) % types.length;
			navigate(P_DELAY);
		});
		button(Component.literal("Random delay: ").append(Fmt.onOff(d.random)), false, btn -> {
			d.random = !d.random;
			navigate(P_DELAY); // bangun ulang supaya slider yang tidak aktif ikut berubah
		});
		slider("Delay manual", d.fixedMs, ModConfig.DELAY_MIN, ModConfig.DELAY_MAX, 100, v -> d.fixedMs = v, !d.random, true);
		slider("Random min", d.minMs, ModConfig.DELAY_MIN, ModConfig.DELAY_MAX, 100, v -> {
			d.minMs = v;
			if (d.maxMs < v) {
				d.maxMs = v;
			}
		}, d.random, false);
		slider("Random maks", d.maxMs, ModConfig.DELAY_MIN, ModConfig.DELAY_MAX, 100, v -> {
			d.maxMs = v;
			if (d.minMs > v) {
				d.minMs = v;
			}
		}, d.random, false);
		endRow();

		String now = d.random
			? "Aktif: random " + sec(Math.min(d.minMs, d.maxMs)) + " - " + sec(Math.max(d.minMs, d.maxMs))
			: "Aktif: manual " + sec(d.fixedMs);
		labels.add(new Txt(Fmt.colored(now, Fmt.GREEN), x0, y));
		y += 12;
		note("Tipe: " + t.label);
		note("Delay = jeda sebelum jawaban dikirim, setelah jawaban siap.");
		note("Random ON: slider manual mati. Tiap tipe soal punya pengaturan sendiri.");
	}

	private void pageFormat(ModConfig.Profile p) {
		intField("Maks kata jawaban [0-20]", () -> p.maxWords, v -> p.maxWords = v, 0, 20, false);
		intField("Cooldown jawaban ms [0-60000]", () -> p.cooldownMs, v -> p.cooldownMs = v, 0, 60000, false);
		cycle("Huruf jawaban", () -> p.answerCase, v -> p.answerCase = v, false);
		toggle("Hapus tanda baca akhir", () -> p.stripTrailingPunct, v -> p.stripTrailingPunct = v, false);
		intField("Jendela konfirmasi ms", () -> p.confirmWindowMs, v -> p.confirmWindowMs = v, 1000, 120000, false);
		textBox("Kata konfirmasi benar (koma)", () -> p.winKeywords, v -> p.winKeywords = v, 200, false);
		textBox("Regex jawaban yang diumumkan server", () -> p.revealRegex, v -> p.revealRegex = v, 400, true);
	}

	private void pageAi(ModConfig.Profile p) {
		textBox("API key Gemini", () -> p.apiKey, v -> p.apiKey = v, 200, true);
		textBox("Model", () -> p.model, v -> p.model = v, 80, false);
		doubleField("Temperature (0.0 - 2.0)", () -> p.temperature, v -> p.temperature = v, false);
		intField("Maks token [8-4096]", () -> p.maxOutputTokens, v -> p.maxOutputTokens = v, 8, 4096, false);
		intField("Timeout HTTP ms [1000-60000]", () -> p.httpTimeoutMs, v -> p.httpTimeoutMs = v, 1000, 60000, false);
		textBox("Base URL API", () -> p.apiBase, v -> p.apiBase = v, 200, true);
		button("▶ Tes koneksi AI", true, btn -> runAiTest(p));
		testY = y;
		y += 12;
	}

	private void pageData(ModConfig.Profile p) {
		note("Tersimpan: " + AnswerStore.size() + " soal   (config/chatgptoss-answers.txt)");
		button("☰ Kelola jawaban   (lihat • edit • tambah • hapus)", true,
			btn -> this.minecraft.gui.setScreen(new AnswersScreen(this, 0, "", null, false)));
		textBox("Prompt sistem AI", () -> p.systemPrompt, v -> p.systemPrompt = v, 2000, true);
		button("↺ Kembalikan prompt default", true, btn -> {
			p.systemPrompt = ModConfig.DEFAULT_PROMPT;
			navigate(P_DATA);
		});
	}

	private void pageStats() {
		ModConfig.Stats s = ModConfig.stats();
		statLine("Soal dijawab", String.valueOf(s.total), Fmt.INFO);
		statLine("Terjawab (menang)", String.valueOf(s.won), Fmt.ANSWERED);
		statLine("Telat (kalah cepat)", String.valueOf(s.late), Fmt.LATE);
		statLine("Win rate", s.winRate() + "%", Fmt.GOLD);
		statLine("Sumber lokal / cache / AI", s.local + " / " + s.cache + " / " + s.ai, Fmt.INFO);
		statLine("Rata-rata waktu siap AI", s.avgAiMs() + " ms", Fmt.INFO);
		y += 6;
		button("↺ Reset statistik", true, btn -> {
			ModConfig.resetStats();
			navigate(P_STATS);
		});
	}

	private void runAiTest(ModConfig.Profile p) {
		aiTest = "Menguji koneksi...";
		aiTestOk = true;
		long t0 = System.currentTimeMillis();
		GeminiClient.ask(p, "Umum", "Apa ibukota Indonesia?").whenComplete((ans, err) -> {
			if (err != null) {
				Throwable t = err instanceof CompletionException && err.getCause() != null ? err.getCause() : err;
				aiTestOk = false;
				aiTest = "Gagal: " + (t.getMessage() != null ? t.getMessage() : t.getClass().getSimpleName());
			} else {
				aiTestOk = true;
				aiTest = "Berhasil (" + (System.currentTimeMillis() - t0) + " ms): " + ans.replaceAll("\\s+", " ");
			}
		});
	}

	// ------------------------------------------------------------------ navigasi

	private void addTabs() {
		int n = ICONS.length;
		int gap = 2;
		tabW = (cw - gap * (n - 1)) / n;
		boolean wide = tabW >= 46;
		for (int i = 0; i < n; i++) {
			final int target = i;
			String label = wide ? ICONS[i] + " " + SHORT[i] : ICONS[i];
			Button b = Button.builder(Component.literal(label), btn -> navigate(target))
				.bounds(x0 + i * (tabW + gap), TAB_Y, tabW, 20).build();
			b.active = i != page; // tab aktif tampak "tertekan"
			addRenderableWidget(b);
		}
	}

	private void navigate(int newPage) {
		ModConfig.save();
		this.minecraft.gui.setScreen(new ConfigScreen(parent, newPage));
	}

	@Override
	public void onClose() {
		ModConfig.save();
		this.minecraft.gui.setScreen(parent);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);

		// header: judul pelangi bergerak di kiri, status ON/OFF + profil di kanan
		graphics.fillGradient(0, 0, this.width, 15, 0xB0000000, 0x00000000);
		graphics.text(this.font, Fmt.titled("⚡", Fmt.NAME, Fmt.phase(3000)), x0, 4, 0xFFFFFFFF, true);
		String prof = "  [" + ModConfig.activeName() + "]";
		String st = ModConfig.isEnabled() ? "✔ ON" : "✖ OFF";
		int profW = this.font.width(prof);
		graphics.text(this.font, Fmt.statusShort(ModConfig.isEnabled()), x0 + cw - profW - this.font.width(st), 4, 0xFFFFFFFF, true);
		graphics.text(this.font, Fmt.colored(prof, Fmt.GRAY), x0 + cw - profW, 4, 0xFFFFFFFF, false);

		// garis di bawah tab: pelangi bergerak, tab aktif lebih tebal
		graphics.fill(x0, TAB_Y + 23, x0 + cw, TAB_Y + 24, 0x33FFFFFF);
		Ui.rainbowBar(graphics, x0 + page * (tabW + 2), TAB_Y + 21, tabW, 3);

		// judul bagian: batang aksen + teks tebal + garis tipis
		for (Section s : sections) {
			graphics.fill(s.x(), s.y() + 1, s.x() + 2, s.y() + 10, 0xFF000000 | Fmt.INFO);
			graphics.text(this.font, Fmt.section(s.text()), s.x() + 6, s.y() + 1, 0xFFFFFFFF, false);
			int lx = s.x() + 6 + this.font.width(s.text()) + 10;
			if (lx < s.x() + cw) {
				graphics.fill(lx, s.y() + 5, s.x() + cw, s.y() + 6, 0x44FFFFFF);
			}
		}
		for (Txt l : labels) {
			graphics.text(this.font, l.text(), l.x(), l.y(), 0xFFFFFFFF, false);
		}
		if (page == P_AI && !aiTest.isEmpty()) {
			graphics.text(this.font, Fmt.colored(Ui.clip(this.font, aiTest, cw), aiTestOk ? Fmt.GREEN : Fmt.RED),
				x0, testY, 0xFFFFFFFF, false);
		}
	}

	// ------------------------------------------------------------------ tata letak (grid 2 kolom)

	/** Ambil satu slot {x, lebar, y}. full = lebar penuh; selain itu setengah lebar (2 kolom jika layar cukup lebar). */
	private int[] slot(boolean full, int h) {
		if (full || cw < 300) {
			endRow();
			int[] r = {x0, cw, y};
			y += h;
			return r;
		}
		int w = (cw - GAP) / 2;
		int[] r = {x0 + col * (w + GAP), w, y};
		rowH = Math.max(rowH, h);
		if (col == 0) {
			col = 1;
		} else {
			col = 0;
			y += rowH;
			rowH = 0;
		}
		return r;
	}

	/** Tutup baris yang baru terisi satu kolom. */
	private void endRow() {
		if (col == 1) {
			y += rowH;
			col = 0;
			rowH = 0;
		}
	}

	private void section(String text) {
		endRow();
		if (!sections.isEmpty()) {
			y += 4;
		}
		sections.add(new Section(text, x0, y));
		y += 14;
	}

	private void note(String text) {
		endRow();
		labels.add(new Txt(Fmt.colored(Ui.clip(this.font, text, cw), Fmt.GRAY), x0, y));
		y += 10;
	}

	private void statLine(String label, String value, int rgb) {
		endRow();
		labels.add(new Txt(Component.empty()
			.append(Fmt.colored(label + ": ", Fmt.GRAY))
			.append(Fmt.colored(value, rgb)), x0, y));
		y += 12;
	}

	// ------------------------------------------------------------------ pembantu widget

	private Button button(String text, boolean full, Button.OnPress onPress) {
		return button(Component.literal(text), full, onPress);
	}

	private Button button(Component text, boolean full, Button.OnPress onPress) {
		int[] s = slot(full, ROW);
		Button b = Button.builder(text, onPress).bounds(s[0], s[2], s[1], 20).build();
		addRenderableWidget(b);
		return b;
	}

	private void toggle(String name, BooleanSupplier get, Consumer<Boolean> set, boolean full) {
		int[] s = slot(full, ROW);
		Button b = Button.builder(toggleText(name, get.getAsBoolean()), btn -> {
			boolean v = !get.getAsBoolean();
			set.accept(v);
			btn.setMessage(toggleText(name, v));
		}).bounds(s[0], s[2], s[1], 20).build();
		addRenderableWidget(b);
	}

	private static Component toggleText(String name, boolean v) {
		return Component.literal(name + ": ").append(Fmt.onOff(v));
	}

	private void cycle(String name, Supplier<String> get, Consumer<String> set, boolean full) {
		int[] s = slot(full, ROW);
		Button b = Button.builder(Component.literal(name + ": " + get.get()), btn -> {
			int i = 0;
			for (int k = 0; k < CASES.length; k++) {
				if (CASES[k].equalsIgnoreCase(get.get())) {
					i = k;
				}
			}
			String next = CASES[(i + 1) % CASES.length];
			set.accept(next);
			btn.setMessage(Component.literal(name + ": " + next));
		}).bounds(s[0], s[2], s[1], 20).build();
		addRenderableWidget(b);
	}

	private void textBox(String name, Supplier<String> get, Consumer<String> set, int max, boolean full) {
		int[] s = slot(full, FIELD_ROW);
		labels.add(new Txt(Fmt.colored(Ui.clip(this.font, name, s[1]), Fmt.GRAY), s[0], s[2]));
		EditBox box = new EditBox(this.font, s[0], s[2] + 10, s[1], 18, Component.literal(name));
		box.setMaxLength(max);
		box.setValue(get.get());
		box.setResponder(set);
		addRenderableWidget(box);
	}

	private void intField(String name, IntSupplier get, IntConsumer set, int min, int max, boolean full) {
		textBox(name, () -> String.valueOf(get.getAsInt()), s -> {
			try {
				int v = Integer.parseInt(s.strip());
				if (v >= min && v <= max) {
					set.accept(v);
				}
			} catch (NumberFormatException ignored) {
				// biarkan nilai lama sampai input valid
			}
		}, 9, full);
	}

	private void doubleField(String name, Supplier<Double> get, Consumer<Double> set, boolean full) {
		textBox(name, () -> String.valueOf(get.get()), s -> {
			try {
				double v = Double.parseDouble(s.strip().replace(',', '.'));
				if (v >= 0.0 && v <= 2.0) {
					set.accept(v);
				}
			} catch (NumberFormatException ignored) {
				// biarkan nilai lama sampai input valid
			}
		}, 8, full);
	}

	private void slider(String name, int initialMs, int min, int max, int step, IntConsumer set, boolean active, boolean full) {
		int[] s = slot(full, ROW);
		MsSlider sl = new MsSlider(s[0], s[2], s[1], name, initialMs, min, max, step, set);
		sl.active = active;
		addRenderableWidget(sl);
	}

	private static String sec(int ms) {
		return String.format(Locale.ROOT, "%.1f s", ms / 1000.0);
	}

	/** Slider yang menampilkan detik (nilai disimpan dalam ms), mis. 0.1 s - 10.0 s kelipatan 0.1. */
	private static final class MsSlider extends AbstractSliderButton {
		private final String name;
		private final int min;
		private final int max;
		private final int step;
		private final IntConsumer set;

		MsSlider(int x, int y, int width, String name, int initialMs, int min, int max, int step, IntConsumer set) {
			super(x, y, width, 20, Component.empty(), toValue(initialMs, min, max));
			this.name = name;
			this.min = min;
			this.max = max;
			this.step = step;
			this.set = set;
			updateMessage();
		}

		private static double toValue(int ms, int min, int max) {
			int c = Math.max(min, Math.min(max, ms));
			return (c - min) / (double) (max - min);
		}

		private int ms() {
			int steps = (int) Math.round(this.value * (max - min) / (double) step);
			return Math.max(min, Math.min(max, min + steps * step));
		}

		@Override
		protected void updateMessage() {
			setMessage(Component.literal(name + ": " + sec(ms())));
		}

		@Override
		protected void applyValue() {
			set.accept(ms());
		}
	}
}
