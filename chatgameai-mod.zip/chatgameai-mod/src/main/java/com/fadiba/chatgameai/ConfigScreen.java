package com.fadiba.chatgameai;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** Layar pengaturan (dibuka dari Mod Menu). Dibagi beberapa halaman supaya muat di layar kecil. */
public final class ConfigScreen extends Screen {
	private static final int W = 300;
	private static final String[] PAGE_NAMES = {
		"Profil & Umum", "Deteksi Chat Game", "Jawaban & Cache", "Format Jawaban", "AI (Gemini)", "Prompt & Data Jawaban"
	};
	private static final String[] CASES = {"ASIS", "LOWER", "UPPER"};

	private record Label(String text, int x, int y) {
	}

	private final Screen parent;
	private final int page;
	private final List<Label> labels = new ArrayList<>();
	private int x0;
	private int y;

	private String newProfile = "";
	private String manualQ = "";
	private String manualA = "";
	private boolean confirmClear;

	public ConfigScreen(Screen parent, int page) {
		super(Component.literal("Chat Game AI"));
		this.parent = parent;
		this.page = Math.max(0, Math.min(PAGE_NAMES.length - 1, page));
	}

	@Override
	protected void init() {
		labels.clear();
		x0 = this.width / 2 - W / 2;
		y = 24;
		ModConfig.Profile p = ModConfig.active();

		switch (page) {
			case 0 -> pageGeneral(p);
			case 1 -> pageDetect(p);
			case 2 -> pageAnswer(p);
			case 3 -> pageFormat(p);
			case 4 -> pageAi(p);
			default -> pageData(p);
		}
		addNav();
	}

	// ------------------------------------------------------------------ halaman

	private void pageGeneral(ModConfig.Profile p) {
		List<String> names = ModConfig.names();
		button("Profil aktif: " + ModConfig.activeName() + "  (klik untuk ganti)", W, btn -> {
			int i = names.indexOf(ModConfig.activeName());
			ModConfig.setActive(names.get((i + 1) % names.size()));
			navigate(0);
		});

		label("Nama profil baru (disalin dari profil aktif)");
		EditBox box = new EditBox(this.font, x0, y, W - 90, 18, Component.literal("Nama profil"));
		box.setMaxLength(32);
		box.setValue(newProfile);
		box.setResponder(s -> newProfile = s);
		addRenderableWidget(box);
		addRenderableWidget(Button.builder(Component.literal("Tambah"), btn -> {
			if (ModConfig.addProfile(newProfile)) {
				navigate(0);
			}
		}).bounds(x0 + W - 86, y - 1, 86, 20).build());
		y += 25;

		int half = W / 2 - 2;
		addRenderableWidget(Button.builder(Component.literal("Reset profil ini"), btn -> {
			ModConfig.resetActive();
			navigate(0);
		}).bounds(x0, y, half, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Hapus profil ini"), btn -> {
			if (ModConfig.deleteActive()) {
				navigate(0);
			}
		}).bounds(x0 + W - half, y, half, 20).build());
		y += 28;

		toggle("Mod aktif", () -> p.enabled, v -> p.enabled = v);
		toggle("Tampilkan info jawaban di chat (lokal)", () -> p.showInfoInChat, v -> p.showInfoInChat = v);
		toggle("Mode debug", () -> p.debug, v -> p.debug = v);
	}

	private void pageDetect(ModConfig.Profile p) {
		field("Kata kunci pemicu (di baris pertama)", () -> p.triggerKeyword, v -> p.triggerKeyword = v, 64);
		intField("Maks baris dibaca setelah pemicu", () -> p.maxLinesAfterTrigger, v -> p.maxLinesAfterTrigger = v, 1, 20);
		intField("Batas waktu menunggu soal (ms)", () -> p.captureTimeoutMs, v -> p.captureTimeoutMs = v, 500, 30000);
		toggle("Abaikan chat pemain (<nama> ...) sebagai pemicu", () -> p.ignorePlayerChat, v -> p.ignorePlayerChat = v);
		toggle("Deteksi soal hitungan tanpa tanda [..]", () -> p.detectMathWithoutTag, v -> p.detectMathWithoutTag = v);
		field("Kategori diabaikan (pisah koma, mis. hadiah,acak)", () -> p.ignoredCategories, v -> p.ignoredCategories = v, 200);
	}

	private void pageAnswer(ModConfig.Profile p) {
		toggle("Hitung soal matematika lokal (tanpa AI, instan)", () -> p.localMathSolver, v -> p.localMathSolver = v);
		toggle("Pakai cache jawaban tersimpan", () -> p.useCache, v -> p.useCache = v);
		toggle("Simpan jawaban AI tanpa menunggu konfirmasi benar", () -> p.saveUnverified, v -> p.saveUnverified = v);
		field("Kata konfirmasi benar (pisah koma)", () -> p.winKeywords, v -> p.winKeywords = v, 200);
		intField("Delay minimum sebelum kirim (ms)", () -> p.minDelayMs, v -> p.minDelayMs = v, 0, 10000);
		intField("Delay maksimum sebelum kirim (ms)", () -> p.maxDelayMs, v -> p.maxDelayMs = v, 0, 10000);
	}

	private void pageFormat(ModConfig.Profile p) {
		intField("Maks kata jawaban (0 = tanpa batas)", () -> p.maxWords, v -> p.maxWords = v, 0, 20);
		cycle("Huruf jawaban", () -> p.answerCase, v -> p.answerCase = v);
		toggle("Hapus tanda baca di akhir jawaban", () -> p.stripTrailingPunct, v -> p.stripTrailingPunct = v);
		intField("Cooldown antar jawaban (ms)", () -> p.cooldownMs, v -> p.cooldownMs = v, 0, 60000);
		intField("Jendela konfirmasi jawaban (ms)", () -> p.confirmWindowMs, v -> p.confirmWindowMs = v, 1000, 120000);
		field("Regex jawaban yang diumumkan server", () -> p.revealRegex, v -> p.revealRegex = v, 400);
	}

	private void pageAi(ModConfig.Profile p) {
		field("API key Gemini", () -> p.apiKey, v -> p.apiKey = v, 200);
		field("Model", () -> p.model, v -> p.model = v, 80);
		field("Base URL API", () -> p.apiBase, v -> p.apiBase = v, 200);
		doubleField("Temperature (0.0 - 2.0)", () -> p.temperature, v -> p.temperature = v);
		intField("Maks token keluaran", () -> p.maxOutputTokens, v -> p.maxOutputTokens = v, 8, 4096);
		intField("Timeout HTTP (ms)", () -> p.httpTimeoutMs, v -> p.httpTimeoutMs = v, 1000, 60000);
	}

	private void pageData(ModConfig.Profile p) {
		field("Prompt sistem AI", () -> p.systemPrompt, v -> p.systemPrompt = v, 2000);
		label("Jawaban tersimpan: " + AnswerStore.size() + "  (config/chatgameai-answers.json)");
		button(confirmClear ? "Yakin? Klik lagi untuk hapus semua" : "Hapus semua data jawaban", W, btn -> {
			if (confirmClear) {
				AnswerStore.clear();
				navigate(5);
			} else {
				confirmClear = true;
				btn.setMessage(Component.literal("Yakin? Klik lagi untuk hapus semua"));
			}
		});
		y += 4;
		textBox("Tambah manual: soal (persis seperti di chat)", () -> manualQ, v -> manualQ = v, 300);
		textBox("Tambah manual: jawaban", () -> manualA, v -> manualA = v, 100);
		button("Simpan jawaban manual", W, btn -> {
			if (!manualQ.isBlank() && !manualA.isBlank()) {
				AnswerStore.put(AnswerStore.norm(manualQ), manualA.strip());
				navigate(5);
			}
		});
	}

	// ------------------------------------------------------------------ navigasi

	private void addNav() {
		int ny = this.height - 24;
		Button prev = Button.builder(Component.literal("< Sebelumnya"), b -> navigate(page - 1))
			.bounds(x0, ny, 90, 20).build();
		prev.active = page > 0;
		addRenderableWidget(prev);
		addRenderableWidget(Button.builder(Component.literal("Selesai"), b -> onClose())
			.bounds(this.width / 2 - 50, ny, 100, 20).build());
		Button next = Button.builder(Component.literal("Berikutnya >"), b -> navigate(page + 1))
			.bounds(x0 + W - 90, ny, 90, 20).build();
		next.active = page < PAGE_NAMES.length - 1;
		addRenderableWidget(next);
	}

	private void navigate(int newPage) {
		ModConfig.save();
		this.minecraft.gui.setScreen(new ConfigScreen(parent, newPage));
	}

	@Override
	public void onClose() {
		ModConfig.save();
		this.minecraft.gui.setScreen(parent);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		String title = "Chat Game AI - " + PAGE_NAMES[page] + " (" + (page + 1) + "/" + PAGE_NAMES.length
			+ ")  [" + ModConfig.activeName() + "]";
		graphics.text(this.font, title, (this.width - this.font.width(title)) / 2, 8, 0xFFFFFFFF, true);
		for (Label l : labels) {
			graphics.text(this.font, l.text(), l.x(), l.y(), 0xFFAAAAAA, false);
		}
	}

	// ------------------------------------------------------------------ pembantu widget

	private void label(String text) {
		labels.add(new Label(text, x0, y));
		y += 10;
	}

	private void button(String text, int width, Button.OnPress onPress) {
		addRenderableWidget(Button.builder(Component.literal(text), onPress).bounds(x0, y, width, 20).build());
		y += 24;
	}

	private void toggle(String name, BooleanSupplier get, Consumer<Boolean> set) {
		Button b = Button.builder(Component.literal(toggleText(name, get.getAsBoolean())), btn -> {
			boolean v = !get.getAsBoolean();
			set.accept(v);
			btn.setMessage(Component.literal(toggleText(name, v)));
		}).bounds(x0, y, W, 20).build();
		addRenderableWidget(b);
		y += 24;
	}

	private static String toggleText(String name, boolean v) {
		return name + ": " + (v ? "ON" : "OFF");
	}

	private void cycle(String name, Supplier<String> get, Consumer<String> set) {
		Button b = Button.builder(Component.literal(name + ": " + get.get()), btn -> {
			int i = 0;
			for (int k = 0; k < CASES.length; k++) {
				if (CASES[k].equalsIgnoreCase(get.get())) {
					i = k;
				}
			}
			String next = CASES[(i + 1) % CASES.length];
			set.accept(next);
			btn.setMessage(Component.literal(name + ": " + next));
		}).bounds(x0, y, W, 20).build();
		addRenderableWidget(b);
		y += 24;
	}

	private void field(String name, Supplier<String> get, Consumer<String> set, int max) {
		textBox(name, get, set, max);
	}

	private void textBox(String name, Supplier<String> get, Consumer<String> set, int max) {
		label(name);
		EditBox box = new EditBox(this.font, x0, y, W, 18, Component.literal(name));
		box.setMaxLength(max);
		box.setValue(get.get());
		box.setResponder(set);
		addRenderableWidget(box);
		y += 21;
	}

	private void intField(String name, IntSupplier get, IntConsumer set, int min, int max) {
		textBox(name + "  [" + min + "-" + max + "]", () -> String.valueOf(get.getAsInt()), s -> {
			try {
				int v = Integer.parseInt(s.strip());
				if (v >= min && v <= max) {
					set.accept(v);
				}
			} catch (NumberFormatException ignored) {
				// biarkan nilai lama sampai input valid
			}
		}, 9);
	}

	private void doubleField(String name, Supplier<Double> get, Consumer<Double> set) {
		textBox(name, () -> String.valueOf(get.get()), s -> {
			try {
				double v = Double.parseDouble(s.strip().replace(',', '.'));
				if (v >= 0.0 && v <= 2.0) {
					set.accept(v);
				}
			} catch (NumberFormatException ignored) {
				// biarkan nilai lama sampai input valid
			}
		}, 8);
	}
}
