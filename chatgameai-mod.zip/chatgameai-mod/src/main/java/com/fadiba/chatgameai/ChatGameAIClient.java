package com.fadiba.chatgameai;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public final class ChatGameAIClient implements ClientModInitializer {
	public static final String MOD_ID = "chatgptoss";

	private static KeyMapping toggleKey;
	private boolean inWorld;

	@Override
	public void onInitializeClient() {
		ModConfig.load();
		AnswerStore.load();

		// Keybind on/off global (ubah di Options > Controls > Key Binds > Chatgpt-oss)
		KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));
		toggleKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
			"key.chatgptoss.toggle", InputConstants.Type.KEYSYM, InputConstants.KEY_K, category));

		// Pesan dari server (plugin biasanya mengirim lewat jalur ini)
		ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
			if (!overlay) {
				ChatGameEngine.onMessage(message);
			}
		});
		// Pesan chat pemain yang ditandatangani
		ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, timestamp) ->
			ChatGameEngine.onMessage(message));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (toggleKey.consumeClick()) {
				boolean on = !ModConfig.isEnabled();
				ModConfig.setEnabled(on);
				if (client.player != null) {
					// status ON/OFF dikirim ke chat client (bukan action bar)
					client.player.sendSystemMessage(Fmt.statusChat(on));
				}
			}

			Notifier.tick(client);

			// Panaskan koneksi ke Gemini saat masuk server
			boolean now = client.player != null;
			if (now && !inWorld) {
				GeminiClient.warmUp(ModConfig.active());
			}
			inWorld = now;
		});
	}
}
