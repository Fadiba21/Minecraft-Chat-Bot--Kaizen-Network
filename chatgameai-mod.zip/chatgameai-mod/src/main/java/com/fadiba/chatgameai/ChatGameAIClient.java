package com.fadiba.chatgameai;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;

public final class ChatGameAIClient implements ClientModInitializer {
	public static final String MOD_ID = "chatgameai";

	private boolean inWorld;

	@Override
	public void onInitializeClient() {
		ModConfig.load();
		AnswerStore.load();

		// Pesan dari server (plugin biasanya mengirim lewat jalur ini)
		ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
			if (!overlay) {
				ChatGameEngine.onMessage(message);
			}
		});
		// Pesan chat pemain yang ditandatangani
		ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, timestamp) ->
			ChatGameEngine.onMessage(message));

		// Panaskan koneksi ke Gemini saat masuk server
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			boolean now = client.player != null;
			if (now && !inWorld) {
				GeminiClient.warmUp(ModConfig.active());
			}
			inWorld = now;
		});
	}
}
