# Chat Game AI (Fabric, Minecraft Java 26.2)

Mod client-side: mendeteksi "Chat Game" di chat server, menjawab soal (lokal atau Gemini),
lalu mengirim jawaban dari akun Minecraft kamu.

## Build
Butuh **JDK 25**: `./gradlew build` -> `build/libs/chatgameai-1.0.0.jar`.
Taruh jar di `mods/` bersama **Fabric API** dan **Mod Menu** (Fabric Loader 0.19.3+).

## Setup
1. **Mods > Chat Game AI > Konfigurasi**.
2. Halaman **AI (Gemini)**: isi API key. Model default `gemini-3.5-flash-lite`.

## Urutan menjawab
1. **Solver lokal** (instan, tanpa AI):
   - `The first to type 'sgo' wins!` / `Ketik 'abc'` -> jawab teks persis
   - `[Logika] (key: 3 down) Pecahkan: odpsx` -> sandi geser huruf (down = mundur, up = maju)
   - Hitungan: `12 + 5`, `Berapa 25 + 17 ?`, `45 plus 55`, `12 ditambah 30`, `7 x 8`
2. **Cache** jawaban yang pernah benar
3. **Gemini** (1-3 kata)

## Delay kirim (halaman "Delay Kirim")
Tiap tipe soal punya pengaturan sendiri: Pertanyaan Biasa, Matematika, Ketik, Pecahkan Kata Acak.
- Slider **Delay manual**: 10 - 5000 ms
- **Random delay ON**: slider manual nonaktif, jawaban dikirim di antara slider **Random minimum** dan **Random maksimum**

## Keybind
ON/OFF global: **Options > Controls > Key Binds > Chat Game AI** (default `K`).
Status tampil di action bar. Saklar yang sama ada di halaman Profil & Umum.

## File
- `config/chatgameai.json` : semua profil + pengaturan (termasuk API key, jangan dibagikan)
- `config/chatgameai-answers.json` : data jawaban (cache)

## Catatan
- Format chat tiap server beda. Kalau soal tidak terdeteksi: nyalakan **Mode debug**
  (baris yang diabaikan akan ditampilkan), lalu sesuaikan halaman Deteksi.
- Pastikan penggunaan bot jawaban otomatis diizinkan oleh aturan server kamu.
