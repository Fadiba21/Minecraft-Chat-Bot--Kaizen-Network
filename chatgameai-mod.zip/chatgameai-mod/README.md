# Chatgpt-oss (Fabric, Minecraft Java 26.2)

Mod client-side: mendeteksi "Chat Game" di chat server, menjawab soal (lokal atau Gemini),
mengirim jawaban dari akun Minecraft kamu, lalu menampilkan **Terjawab** / **Telat**.

## Build
Butuh **JDK 25**: `./gradlew build` -> `build/libs/chatgameai-1.0.0.jar`
(nama file jar sengaja tidak diubah supaya workflow GitHub lama tetap jalan; nama mod di game: Chatgpt-oss).
Taruh jar di `mods/` bersama **Fabric API** dan **Mod Menu** (Fabric Loader 0.19.3+).

## Setup
1. **Mods > Chatgpt-oss > Konfigurasi** (butuh Mod Menu).
2. Tab **AI**: isi API key, lalu tekan **Tes koneksi AI**. Model default `gemini-3.5-flash-lite`.
3. Tab **Notif**: pastikan IGN benar (default `Feyy4314`).

## Urutan menjawab
1. **Solver lokal** (instan): `The first to type 'sgo'`, sandi `(key: 3 down) Pecahkan: odpsx`, hitungan `'4 x 8 = ?'`, `Berapa 25 + 17`.
2. **Cache** jawaban yang pernah benar
3. **Gemini** (1-3 kata)

## Terjawab / Telat
Saat server mengumumkan pemenang (`Nama typed 'x' in 3.6 seconds`, `Nama solved 4 x 8 (32) in 3 seconds`, `answered`, ...):
- nama = IGN kamu -> action bar **Terjawab** (hijau muda)
- nama lain -> action bar **Telat** (merah muda)

Tampil 4 detik (bisa diatur 1-10 detik), dengan 4 huruf acak RGB di kiri dan kanan. Jawaban yang masih menunggu delay otomatis dibatalkan kalau ronde sudah dimenangkan orang lain.

## Delay kirim (tab "Delay")
Per tipe soal: Biasa, Matematika, Ketik, Pecahkan/Sandi. Slider 0.1 - 10 detik (kelipatan 0.1).
Random delay ON: slider manual mati, jawaban dikirim di antara slider min dan maks.

## Keybind
ON/OFF global: **Options > Controls > Key Binds > Chatgpt-oss** (default `K`). Status ON/OFF muncul di chat.

## Kelola jawaban (tab "Data")
Cari, lihat, edit, tambah, hapus satu per satu, atau hapus semua. File: `config/chatgptoss-answers.txt`
(format `soal ||| jawaban`, boleh diedit manual).

## File
- `config/chatgptoss.json` : semua profil + pengaturan + statistik (termasuk API key, jangan dibagikan)
- `config/chatgptoss-answers.txt` : data jawaban
File lama (`ethenalabs-*`, `chatgameai*`) otomatis dimigrasikan.

## Catatan
- Format chat tiap server beda. Kalau soal tidak terdeteksi: nyalakan **Mode debug** (baris yang diabaikan ditampilkan).
- Pastikan penggunaan bot jawaban otomatis diizinkan oleh aturan server kamu.
