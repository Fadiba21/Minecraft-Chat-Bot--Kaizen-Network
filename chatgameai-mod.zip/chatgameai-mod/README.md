# Chat Game AI (Fabric, Minecraft Java 26.2)

Mod client-side: mendeteksi "Chat Game" di chat server, menjawab soal dengan Gemini
(1-3 kata, cepat), lalu mengirim jawaban dari akun Minecraft kamu.

## Build
Butuh **JDK 25**. Dari folder proyek:

    ./gradlew build          (Windows: gradlew.bat build)

Hasil: `build/libs/chatgameai-1.0.0.jar` -> taruh di folder `mods/` bersama
**Fabric API** dan **Mod Menu** (Fabric Loader 0.19.3+).

Jika Mod Menu gagal diunduh dari maven.terraformersmc.com, ganti repo/dependensinya
dengan Modrinth maven (`maven.modrinth:modmenu:<versi>`) atau pakai jar lokal.

## Setup
1. Buka **Mods > Chat Game AI > Konfigurasi** (butuh Mod Menu).
2. Halaman **AI (Gemini)**: isi API key. Model default `gemini-3.5-flash-lite`.
3. Selesai. Saat soal muncul, mod menjawab otomatis.

## Cara kerja
1. Baris chat berisi kata pemicu (default `Chat Game`) -> mod mulai membaca baris berikutnya.
2. Baris `[Jenis] soal` -> jenis + soal. Soal hitungan tanpa `[..]` juga dikenali.
3. Urutan jawab: hitung lokal (instan) -> cache -> Gemini.
4. Jawaban dikirim lewat client (akun kamu). Info "Jawab (ai, 410 ms): ..." muncul lokal.
5. Jawaban disimpan ke cache jika server mengumumkan kamu menang (nama kamu + kata
   konfirmasi) atau server menampilkan jawaban benar (regex). Opsi "simpan tanpa konfirmasi"
   tersedia.

## File
- `config/chatgameai.json` : semua profil + pengaturan (termasuk API key, jangan dibagikan)
- `config/chatgameai-answers.json` : data jawaban (cache)

## Catatan
- Format chat tiap server beda. Kalau tidak terdeteksi: nyalakan **Mode debug**,
  sesuaikan kata pemicu / jumlah baris di halaman Deteksi.
- Pastikan penggunaan bot jawaban otomatis diizinkan oleh aturan server kamu.
